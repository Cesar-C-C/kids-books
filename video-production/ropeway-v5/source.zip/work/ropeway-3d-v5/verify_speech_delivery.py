from pathlib import Path
import json, subprocess, hashlib, re, copy

B = Path(__file__).resolve().parent
R = B.parents[1]
O = R / 'outputs'
P = R / 'work/ropeway-3d-v4'
FF = R / 'work/video-tools/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
FP = R / 'work/video-tools/node_modules/@ffprobe-installer/win32-x64/ffprobe.exe'

revision = json.loads((B / 'speech-revisions.json').read_text(encoding='utf8'))
audio = json.loads((B / 'audio-patch-qa.json').read_text(encoding='utf8'))
asr = json.loads((B / 'speech-asr-final.json').read_text(encoding='utf8'))
punctuation = re.compile('[^\u4e00-\u9fff]')
prosody = []
for beat in revision['beats']:
    q = next(x for x in asr if x['id'] == beat['id'])
    path = B / 'audio-zh-prepared' / (beat['id'] + '.wav')
    assert hashlib.sha256(path.read_bytes()).hexdigest() == q['audio_sha256']
    assert beat['keyword'] in punctuation.sub('', q['recognized'])
    assert beat['keyword'] in q['recognized']
    if beat['id'] == 's31b1':
        assert q['recognized'].lstrip().startswith('不故意') and '我们' not in q['recognized']
    words = q['words']
    chars, owners = '', []
    for i, w in enumerate(words):
        text = punctuation.sub('', w['word'])
        chars += text
        owners += [i] * len(text)
    first = chars.index(beat['keyword'])
    indices = sorted(set(owners[first:first + len(beat['keyword'])]))
    gaps = [max(0, words[j]['start'] - words[i]['end']) for i, j in zip(indices, indices[1:])]
    assert max(gaps, default=0) <= .08
    fit = next(x for x in audio['replacements'] if x['id'] == beat['id'])
    assert abs(fit['loudness_delta_db']) < 2 and fit['tempo'] <= 1.35
    prosody.append({'id': beat['id'], 'keyword': beat['keyword'], 'maximum_internal_word_gap_seconds': max(gaps, default=0),
                    'recognized': q['recognized'], 'prepared_audio_hash_verified': True,
                    'loudness_difference_db': fit['loudness_delta_db']})

old_t = json.loads((P / 'full-timing.json').read_text(encoding='utf8'))
new_t = json.loads((B / 'full-timing.json').read_text(encoding='utf8'))
expected = copy.deepcopy(old_t)
expected['version'] = new_t['version']
for scene in expected['scenes']:
    for beat in scene['beats']:
        if beat['id'] == 's31b2':
            beat['zh'] = '如果担心，告诉大人，按标示的指引联系工作人员。'
assert expected == new_t
old_srt = (O / 'ropeway-3d-v4-bilingual.srt').read_text(encoding='utf8')
new_srt = (O / 'ropeway-3d-v5-bilingual.srt').read_text(encoding='utf8')
assert old_srt.replace('担心什么？告诉大人，按标示的指引联系工作人员。', '如果担心，告诉大人，按标示的指引联系工作人员。') == new_srt
assert len(new_srt.strip().split('\n\n')) == 104
assert (P / 'narration-en.m4a').read_bytes() == (B / 'narration-en.m4a').read_bytes()
assert (P / 'ropeway-model-library.blend').read_bytes() == (B / 'ropeway-model-library.blend').read_bytes()

media = json.loads(subprocess.check_output([str(FP), '-v', 'error', '-count_frames', '-show_streams',
    '-show_format', '-of', 'json', str(O / 'ropeway-3d-v5.mp4')], text=True))
video = next(s for s in media['streams'] if s['codec_type'] == 'video')
tracks = [s for s in media['streams'] if s['codec_type'] == 'audio']
assert (video['width'], video['height'], video['avg_frame_rate'], int(video['nb_read_frames'])) == (1920, 1080, '24/1', 14340)
assert [s['tags']['language'] for s in tracks] == ['zho', 'eng'] and tracks[0]['disposition']['default'] == 1
assert abs(float(media['format']['duration']) - 597.5) < .05
with (B / 'decode.log').open('wb') as log:
    subprocess.run([str(FF), '-v', 'error', '-i', str(O / 'ropeway-3d-v5.mp4'), '-map', '0', '-f', 'null', 'NUL'], stderr=log, check=True)
assert (B / 'decode.log').stat().st_size == 0

saved = json.loads((B / 'preserved.json').read_text(encoding='utf8'))
assert all(hashlib.sha256((O / name).read_bytes()).hexdigest() == digest for name, digest in saved.items())
picture = json.loads((B / 'video-patch-qa.json').read_text(encoding='utf8'))
assert picture['unchanged_picture_payloads_verified'] and picture['packet_count'] == 14340
player = json.loads((B / 'full-player-qa.json').read_text(encoding='utf8'))
assert player['ok'] and not player['errors'] and not player['externalRequests']
visual = json.loads((B / 'correction-visual-qa.json').read_text(encoding='utf8'))
assert visual['manual_review_ok']
report = {'ok': True, 'scope': 'Local corrected speech, word timing evidence, final subtitle frames, full stream decode, and automated browser playback. No new human-listening or physical-device acceptance is implied.',
          'duration': 597.5, 'resolution': [1920, 1080], 'fps': 24, 'frames': 14340,
          'caption_pairs': 104, 'subtitle_pairs_changed': 1, 'mandarin_sentences_replaced': 3,
          'english_master_bit_identical': True, 'scene_and_beat_timestamps_unchanged': True,
          'prior_output_files_preserved': len(saved), 'full_decode': True,
          'word_continuity': prosody, 'audio_patch': audio, 'video_patch': picture,
          'browser': player, 'visual': visual}
(B / 'final-qa.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({'ok': True, 'duration': 597.5, 'preserved_files': len(saved), 'word_continuity_checks': len(prosody), 'player_checks': len(player['cases'])}))
