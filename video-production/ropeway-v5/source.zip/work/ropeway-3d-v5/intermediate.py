"""Through-running middle station: two separate rope loops, one cabin."""
import math,json
from pathlib import Path

def build_intermediate(g):
 box=g['box'];cy=g['cylinder'];tube=g['tube'];tor=g['torus'];M=g['M'];sm=g['smooth'];look=g['look']
 def lane(x):return 1.0*sm(-6.0,-3.3,x)*(1-sm(.5,2.5,x))
 def angle(x):return math.atan2(lane(x+.001)-lane(x-.001),.002)
 wheels=[]
 for x in [-2.5,2.5]:wheels.append(g['model_wheel'](x,-2.2,4.08,2.2))
 for side in [-1,1]:
  pts=[(side*(2.5+9*j/90),0,4.08) for j in range(90,-1,-1)]
  a0=math.pi/2
  for j in range(81):
   a=a0+(-1 if side<0 else 1)*math.pi*j/80
   pts.append((side*2.5+2.2*math.cos(a),-2.2+2.2*math.sin(a),4.08))
  pts.extend([(side*(2.5+9*j/90),-4.4,4.08) for j in range(91)])
  tube('Section A rope loop' if side<0 else 'Section B rope loop',pts,.042,M['steel'])
 for side in [-1,1]:tube('Continuous middle-station support rail',[(x,lane(x)+side*.62,3.903) for x in [-8.75+j*16.2/240 for j in range(241)]],.047,M['rail'])
 for x in [-8,-6,-4,-2,0,2,4,6,7]:
  y=lane(x)-.95;box('Middle station support column',(x,y,1.9),(.16,.16,3.8),M['sage'])
  box('Middle station rail bracket',(x,lane(x),3.79),(.15,1.75,.12),M['steel'])
  box('Middle station support base',(x,y,.09),(.4,.4,.12),M['steel'])
 hubs=[]
 for j in range(33):
  x=-8+j*.48;a=angle(x);h=g['empty']('Connecting conveyor tire',(x+math.sin(a)*.24,lane(x)-math.cos(a)*.24,4.7655));h.rotation_euler.z=a;hubs.append(h)
  tor('Middle station conveyor tire',(0,0,0),.19,.068,M['rubber'],h)
  cy('Middle station conveyor hub',(0,.083,0),.10,.024,M['steel'],h,'Y')
  box('Middle conveyor hub mark',(0,.1,0),(.018,.017,.16),M['white'],h,.004)
  box('Middle conveyor fixed bearing',(0,-.23,0),(.15,.25,.14),M['sage'],h,.025)
 tube('Connecting conveyor support beam',[(-8,-.9,4.8),(0,.05,4.8),(7,-.9,4.8)],.064,M['sage'])
 guide=[]
 for j in range(241):
  x=-8.75+j*16.2/240;op=sm(-7.6,-6.5,x)*(1-sm(3.3,4.3,x));a=angle(x);r=.34+.4*op;guide.append((x-math.sin(a)*r,lane(x)+math.cos(a)*r,4.37))
 tube('Middle station grip release guide',guide,.025,M['spring'])
 box('Middle station boarding platform',(-.3,2.7,.56),(9.3,2,.32),M['sage'],bevel=.13)
 box('Middle station tactile edge',(-.3,1.72,.732),(8.4,.12,.016),M['spring'],bevel=.006)
 for x in [-4,-2,0,2,4]:
  cy('Platform railing post',(x,3.65,1.16),.027,1.0,M['steel'])
 for z in [1.22,1.64]:tube('Platform guard railing',[(-4.8,3.65,z),(4.6,3.65,z)],.025,M['steel'])
 c=g['copy_tree'](g['carrier']);c.name='Same_cabin_through_middle_station';c['asset_id']='explorer-cabin-v2'
 jaw=next(o for o in g['descend'](c) if o.name.startswith('Moving_grip_jaw'))
 coils=[o for o in g['descend'](c) if o.name.startswith('Parallel compression spring')]
 def state(u):
  t=max(0,min(1,u))*30
  if t<3:x=-8.4+.85*t;v=.85
  elif t<9:
   dt=t-3;a=(.22-.85)/6;x=-5.85+.85*dt+.5*a*dt*dt;v=.85+a*dt
  elif t<18:x=-2.64+.22*(t-9);v=.22
  elif t<25.2:
   dt=t-18;a=(.85-.22)/7.2;x=-.66+.22*dt+.5*a*dt*dt;v=.22+a*dt
  else:x=3.192+.85*(t-25.2);v=.85
  op=sm(-7.6,-6.5,x)*(1-sm(3.3,4.3,x));return x,v,op
 def update(u,variant):
  x,v,op=state(u);c.location=(x,lane(x),0);c.rotation_euler.z=angle(x);jaw.location.y=.4*op
  for sp in coils:sp.scale.y=1-.22*op;sp.location.y=-.11*op
  for w in wheels:w.rotation_euler.z=-u*30*.85/2.2
  for h in hubs:h.rotation_euler.y=-u*30*.22/.258
  close=sm(.10,.23,u)*(1-sm(.79,.95,u));look((x*close,lane(x)*close,2.8),(-10+5*close,16-6*close,8-4*close),25-12*close)
 states=[state(i/720) for i in range(721)]
 tests={'continuous_support':all(-8.75+.31<=x<=7.45-.31 or op<.015 for x,v,op in states),'release_before_deceleration':state(.1)[2]>.985,'closes_only_after_speed_match':all(abs(v-.85)<1e-5 for x,v,op in states if x>0 and op<.985),'closed_rope_alignment':all(abs(lane(x))<.002 for x,v,op in states if op<.015),'next_rope_present_before_closure':all(x>=2.5 for x,v,op in states if x>0 and op<.985),'same_cabin_no_transfer':True,'scope':'illustrative two-section through-running detachable system; not every middle station'}
 assert all(v for k,v in tests.items() if k!='scope'),tests
 (Path(g['BASE'])/'intermediate-qa.json').write_text(json.dumps(tests,indent=2))
 return update
