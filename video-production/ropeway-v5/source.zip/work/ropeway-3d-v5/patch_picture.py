"""Replace the GOP containing the changed subtitle; copy every other video packet."""
from pathlib import Path
import json, subprocess
import hashlib

B = Path(__file__).resolve().parent
R = B.parents[1]
PREV = R / 'work/ropeway-3d-v4'
FF = R / 'work/video-tools/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
FP = R / 'work/video-tools/node_modules/@ffprobe-installer/win32-x64/ffprobe.exe'
START = 12118 / 24
END = 12618 / 24

def run(args, cwd=None):
    subprocess.run([str(FF), '-v', 'error', '-y', *map(str, args)], check=True, cwd=cwd)

def packets(path):
    return json.loads(subprocess.check_output([
        str(FP), '-v', 'error', '-select_streams', 'v:0', '-show_packets',
        '-show_data_hash', 'sha256', '-show_entries', 'packet=pts_time,data_hash',
        '-of', 'json', str(path)
    ], text=True))['packets']

def check_packets():
    old = packets(PREV / 'picture.mp4')
    new = packets(B / 'picture.mp4')
    a = {round(float(p['pts_time']) * 24): p['data_hash'] for p in old}
    b = {round(float(p['pts_time']) * 24): p['data_hash'] for p in new}
    assert set(a) == set(b) == set(range(14340))
    outside = [i for i in a if not 12118 <= i < 12618]
    # The concat demuxer inserts existing SPS/PPS headers at keyframes.
    # Compare the picture-bearing NAL payload where container hashes differ.
    different = [i for i in outside if a[i] != b[i]]
    def picture_hash(path, frame):
        rows = json.loads(subprocess.check_output([
            str(FP), '-v', 'error', '-select_streams', 'v:0', '-read_intervals',
            f'{frame/24+.001:.9f}%+#1', '-show_packets', '-show_data',
            '-show_entries', 'packet=pts_time,data,size,flags', '-of', 'json', str(path)
        ], text=True))['packets']
        p = rows[0]
        assert round(float(p['pts_time']) * 24) == frame and 'K' in p['flags']
        raw = bytes.fromhex(''.join(line.split(':', 1)[1].strip().split('  ')[0].replace(' ', '')
                             for line in p['data'].splitlines() if ':' in line))
        assert len(raw) == int(p['size'])
        payload, offset = [], 0
        while offset < len(raw):
            length = int.from_bytes(raw[offset:offset+4], 'big')
            nal = raw[offset+4:offset+4+length]
            assert len(nal) == length
            if nal[0] & 31 not in [7, 8]:
                payload.append(nal)
            offset += length + 4
        assert offset == len(raw)
        return hashlib.sha256(b''.join(payload)).hexdigest()
    for i in different:
        assert picture_hash(PREV / 'picture.mp4', i) == picture_hash(B / 'picture.mp4', i)
    pts = sorted(float(x['pts_time']) for x in new)
    assert abs(pts[0]) < .001 and all(abs(y - x - 1 / 24) < .001 for x, y in zip(pts, pts[1:]))
    report = {'reencoded_interval': [START, END], 'reencoded_frames': 500,
              'unchanged_picture_payload_frames': len(outside), 'unchanged_picture_payloads_verified': True,
              'container_packet_hashes_identical': len(outside) - len(different),
              'keyframes_with_repeated_sps_pps_only': len(different),
              'packet_count': len(pts), 'regular_24fps_timestamps': True}
    (B / 'video-patch-qa.json').write_text(json.dumps(report, indent=2), encoding='utf8')
    print(json.dumps(report))

def build():
    from compose_film import subtitles
    subtitles()
    dest = B / 'video-patch'
    dest.mkdir(exist_ok=True)
    run(['-i', PREV / 'picture.mp4', '-map', '0:v', '-c', 'copy', '-f', 'segment',
         '-segment_times', f'{START:.9f},{END:.9f}', '-segment_time_delta', '.02',
         '-reset_timestamps', '1', dest / 'part-%d.mp4'])
    run(['-ss', START, '-i', PREV / 'background.mp4', '-vf',
         f'setpts=PTS+{START:.10f}/TB,ass=film.ass,setpts=PTS-STARTPTS',
         '-frames:v', 500, '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', 19,
         '-pix_fmt', 'yuv420p', dest / 'revised.mp4'], cwd=B)
    chunks = [('part-0.mp4', START), ('revised.mp4', END - START), ('part-2.mp4', 597.5 - END)]
    concat = dest / 'concat.txt'
    concat.write_text(''.join("file '" + (dest / name).as_posix() + "'\nduration " + str(duration) + '\n' for name, duration in chunks), encoding='utf8')
    run(['-f', 'concat', '-safe', '0', '-i', concat, '-c', 'copy', B / 'picture.mp4'])
    check_packets()

if __name__ == '__main__':
    import sys
    check_packets() if '--check' in sys.argv else build()
