from pathlib import Path
import subprocess, shutil, json
from compose_film import player

B = Path(__file__).resolve().parent
R = B.parents[1]
O = R / 'outputs'
FF = R / 'work/video-tools/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
T = json.loads((B / 'full-timing.json').read_text(encoding='utf8'))

def run(args):
    subprocess.run([str(FF), '-v', 'error', '-y', *map(str, args)], check=True)

run(['-i', B / 'picture.mp4', '-i', B / 'narration-zh.m4a', '-i', B / 'narration-en.m4a',
     '-map', '0:v', '-map', '1:a', '-map', '2:a', '-c', 'copy',
     '-metadata:s:a:0', 'language=zho', '-metadata:s:a:0', 'title=普通话',
     '-metadata:s:a:1', 'language=eng', '-metadata:s:a:1', 'title=English',
     '-disposition:a:0', 'default', '-disposition:a:1', '0', '-movflags', '+faststart',
     O / 'ropeway-3d-v5.mp4'])
run(['-i', B / 'picture.mp4', '-i', B / 'narration-en.m4a', '-map', '0:v', '-map', '1:a',
     '-c', 'copy', '-movflags', '+faststart', B / 'browser.mp4'])
shutil.copy2(O / 'ropeway-3d-v4-cover.jpg', O / 'ropeway-3d-v5-cover.jpg')
shutil.copy2(B / 'ropeway-model-library.blend', O / 'ropeway-3d-v5-models.blend')
player(B / 'browser.mp4')

def stamp(t):
    n = round(t * 1000)
    return f'{n//3600000:02d}:{n//60000%60:02d}:{n//1000%60:02d},{n%1000:03d}'

lines = []
for i, scene in enumerate(T['scenes']):
    end = T['scenes'][i+1]['start'] if i+1 < len(T['scenes']) else T['duration']
    for j, beat in enumerate(scene['beats']):
        until = scene['beats'][j+1]['start'] if j+1 < len(scene['beats']) else end
        lines.append(f'{len(lines)+1}\n{stamp(beat["start"])} --> {stamp(until)}\n{beat["en"]}\n{beat["zh"]}\n')
(O / 'ropeway-3d-v5-bilingual.srt').write_text('\n'.join(lines), encoding='utf8')

run(['-ss', 152.5, '-t', 8, '-i', O / 'ropeway-3d-v5.mp4',
     '-ss', 508.5, '-t', 15, '-i', O / 'ropeway-3d-v5.mp4',
     '-filter_complex', '[0:v]setpts=PTS-STARTPTS[v0];[0:a:0]asetpts=PTS-STARTPTS[a0];[1:v]setpts=PTS-STARTPTS[v1];[1:a:0]asetpts=PTS-STARTPTS[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]',
     '-map', '[v]', '-map', '[a]', '-frames:v', 552, '-c:v', 'libx264', '-preset', 'fast',
     '-crf', 20, '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart',
     O / 'ropeway-3d-v5-corrections-preview.mp4'])
run(['-ss', 4, '-i', O / 'ropeway-3d-v5-corrections-preview.mp4', '-frames:v', 1,
     '-q:v', 2, O / 'ropeway-3d-v5-corrections-preview.jpg'])
print('Delivered v5 full bilingual film, offline player, SRT, and 23-second correction preview.')
