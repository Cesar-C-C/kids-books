"""Shared manufactured detail for every view of the same teaching assets."""
import bpy,math
from mathutils import Vector

def bolt(g,name,loc,r=.027,par=None,axis='Z'):
 return g['cylinder'](name,loc,r,r*.65,g['M']['steel'],par,axis,vertices=6)

def ring(g,name,z,w,d,radius,material,par):
 points=[]
 for cx,cy,a in [(w/2-radius,d/2-radius,0),(-w/2+radius,d/2-radius,90),(-w/2+radius,-d/2+radius,180),(w/2-radius,-d/2+radius,270)]:
  for j in range(13):
   t=math.radians(a+j*90/12);points.append((cx+radius*math.cos(t),cy+radius*math.sin(t),z))
 points.append(points[0]);return g['tube'](name,points,.016,material,par)

def enhance_carrier(g):
 M=g['M'];c=g['carrier'];box=g['box'];cy=g['cylinder'];tube=g['tube']
 c['asset_id']='explorer-cabin-v2';c['units']='metres';c['body_size']=[1.76,1.46,1.78]
 # A lightly bowed shell with continuous corners replaces the block-shaped lower body.
 old=next(o for o in c.children if o.name=='Orange lower cabin')
 verts=[];faces=[];N=64
 for z,w,d in [(.87,1.62,1.33),(.94,1.75,1.45),(1.37,1.79,1.47),(1.57,1.75,1.44)]:
  for j in range(N):
   a=j*math.tau/N;co=math.cos(a);si=math.sin(a)
   verts.append((w/2*math.copysign(abs(co)**.36,co),d/2*math.copysign(abs(si)**.36,si),z))
 for k in range(3):
  for j in range(N):faces.append((k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j))
 faces.extend([tuple(reversed(range(N))),tuple(range(3*N,4*N))])
 mesh=bpy.data.meshes.new('Formed aluminium cabin shell');mesh.from_pydata(verts,[],faces);mesh.update()
 old.data=mesh;old.location=(0,0,0)
 old.modifiers.clear();sub=old.modifiers.new('Smooth formed shell','SUBSURF');sub.levels=1
 for p in mesh.polygons:p.use_smooth=True
 mesh.materials.append(M['orange'])
 for z,w,d in [(1.56,1.76,1.47),(.91,1.74,1.44),(2.65,1.89,1.60)]:ring(g,'Continuous shell trim',z,w,d,.18,M['green'] if z<1 else M['steel'],c)
 # Glass, seals, door jambs and panel seams belong to the canonical cabin.
 p=M['glass'].node_tree.nodes.get('Principled BSDF');p.inputs['Metallic'].default_value=.24;p.inputs['Roughness'].default_value=.16;p.inputs['Alpha'].default_value=1
 M['glass'].surface_render_method='DITHERED'
 for y in [-.735,.735]:
  for x in [-.43,.43]:
   for z in [1.62,2.49]:box('Window gasket horizontal',(x,y,z),(.72,.016,.032),M['rubber'],c,.009)
   for dx in [-.355,.355]:box('Window gasket vertical',(x+dx,y,2.055),(.025,.017,.88),M['rubber'],c,.008)
  box('Door lower split',(0,y,1.23),(.018,.012,.55),M['green'],c,.004)
  box('Door sill',(0,y,.91),(1.55,.07,.035),M['steel'],c,.009)
  for x in [-.82,.82]:
   for z in [1.69,2.34]:cy('Door hinge',(x,y,z),.032,.09,M['steel'],c)
  box('Roof ventilation grille',(0,y*.70,2.66),(.62,.15,.025),M['steel'],c,.015)
  for x in [-.24,-.16,-.08,0,.08,.16,.24]:box('Vent slot',(x,y*.70,2.678),(.023,.105,.012),M['rubber'],c,.004)
 for x in [-.84,.84]:
  for z in [1.62,2.49]:box('End window seal',(x,0,z),(.027,1.14,.035),M['rubber'],c,.010)
 for y in [-.44,.44]:
  box('Upholstered bench',(0,y,1.49),(1.30,.32,.10),M['sage'],c,.065)
  box('Bench back',(0,y*1.30,1.70),(1.29,.065,.38),M['sage'],c,.065)
 for x in [-.56,.56]:tube('Cabin interior handhold',[(x,-.57,1.65),(x,-.57,2.37),(x,.57,2.37),(x,.57,1.65)],.018,M['steel'],c)
 for y in [-.47,.47]:box('Roof joint plate',(.10,y,2.68),(.31,.21,.035),M['steel'],c,.025)
 for y in [-.51,-.43,.43,.51]:bolt(g,'Roof joint fastener',(.10,y,2.713),par=c)
 for x in [-.37,-.09]:bolt(g,'Hanger pivot bolt',(x,.213,4.16),.045,c,'Y')
 for x in [-.41,.41]:
  for y in [-.45,.45]:bolt(g,'Carrier chassis bolt',(x,y,4.319),par=c)
 for hub in g['running']:
  for a in range(5):
   t=a*math.tau/5;bolt(g,'Wheel hub fastener',(.046*math.sin(t),.092,.046*math.cos(t)),.012,hub,'Y')
  cy('Running wheel bearing',(0,-.08,0),.08,.045,M['steel'],hub,'Y')
 for x in [-.24,.24]:
  cy('Spring guide rod',(x,-.24,4.38),.023,.63,M['steel'],c,'Y')
  cy('Spring rear nut',(x,-.59,4.38),.04,.037,M['steel'],c,'Y',vertices=6)
 for x in [-.19,.19]:bolt(g,'Grip housing bolt',(x,-.108,4.139),par=c)
 tube('Grip control linkage',[(0,.18,4.35),(0,.27,4.44),(0,.47,4.37)],.026,M['steel'],g['moving'])
 # All copies share the same mesh/material assets; cutaways only remove documented panels.

def enhance_station(g):
 box=g['box'];M=g['M'];cy=g['cylinder'];tube=g['tube']
 for x in [-6,-3,0,3,5.3]:
  y=g['lane_y'](x)-.86
  box('Column mounting foot',(x,y,.075),(.34,.34,.10),M['steel'])
  for dx in [-.11,.11]:
   for dy in [-.11,.11]:bolt(g,'Column anchor bolt',(x+dx,y+dy,.143))
  tube('Station diagonal brace',[(x-.40,y,3.24),(x,y,3.8),(x+.40,y,3.24)],.036,M['steel'])
 for hub,v in g['tires']:
  cy('Tire conveyor bearing',(0,-.12,0),.082,.16,M['steel'],hub,'Y')
  box('Tire mounting block',(0,-.28,0),(.15,.21,.14),M['sage'],hub,.025)
  for i in range(12):
   a=i*math.tau/12;o=box('Rubber tire tread',(.255*math.sin(a),0,.255*math.cos(a)),(.037,.10,.017),M['rubber'],hub,.006);o.rotation_euler[1]=a
 box('Conveyor service beam',(0,-.95,4.78),(11.5,.13,.17),M['sage'])
 box('Station tiled platform',(-.2,2.05,.69),(5.3,1.65,.025),M['cream'],bevel=.01)
 for x in [-2.4,-1.7,-1,-.3,.4,1.1,1.8,2.4]:box('Platform tile joint',(x,2.05,.711),(.014,1.6,.006),M['sage'],bevel=0)
 for z in [1.22,1.65]:tube('Platform railing',[(-2.6,2.78,z),(2.45,2.78,z)],.023,M['steel'])
 for x in [-2.6,-1.3,0,1.3,2.45]:cy('Platform rail post',(x,2.78,1.17),.027,1.0,M['steel'])

def enhance_wheel(g,root,r):
 M=g['M']
 for z in [-.085,.085]:g['torus']('Machined wheel flange',(0,0,z),r-.075,.027,M['steel'],root,axis='Z')
 for a in range(8):
  t=a*math.tau/8;bolt(g,'Wheel flange bolt',(.30*math.cos(t),.30*math.sin(t),.106),.031,root)
 for z in [-.16,.16]:g['cylinder']('Axle bearing flange',(0,0,z),.33,.055,M['steel'],root)

def enhance_tower(g):
 M=g['M'];box=g['box'];cy=g['cylinder'];tube=g['tube']
 box('Tower base plate',(0,-1.35,.35),(.95,1.03,.08),M['steel'])
 for x in [-.35,.35]:
  for y in [-1.75,-.95]:bolt(g,'Tower anchor nut',(x,y,.425),.06)
 for z in [.9,1.75,2.6]:box('Tower welded band',(0,-1.35,z),(.52,.57,.045),M['steel'])
 for z in [i*.26+.62 for i in range(10)]:tube('Tower access ladder rung',[(-.20,-1.70,z),(.20,-1.70,z)],.020,M['steel'])
 for x in [-.24,.24]:tube('Ladder upright',[(x,-1.70,.5),(x,-1.70,3.4)],.023,M['steel'])
 box('Service catwalk',(0,-1.15,3.35),(3.6,.75,.09),M['steel'])
 for i in range(18):box('Catwalk grating',(i*.19-1.65,-1.15,3.404),(.038,.70,.018),M['green'],bevel=.005)
 for z in [3.72,4.12]:tube('Catwalk safety railing',[(-1.8,-1.53,z),(1.8,-1.53,z)],.025,M['steel'])
 for x in [-1.8,0,1.8]:cy('Catwalk railing post',(x,-1.53,3.75),.025,.82,M['steel'])
 for x in [-1.8,-1.08,-.36,.36,1.08,1.8]:
  box('Sheave bearing mount',(x,-.38,3.704),(.21,.26,.30),M['green'])
  cy('Sheave supporting axle',(x,-.18,3.808),.045,.42,M['steel'],axis='Y')
  for y in [-.49,-.27]:bolt(g,'Sheave axle bolt',(x,y,3.854),.024)
 tube('Tower sensor conduit',[(0,-1.65,.40),(0,-1.65,3.30),(1.80,-.30,3.30),(1.80,-.30,3.90)],.014,M['rubber'])
 box('Rope position sensor',(1.80,.29,3.99),(.19,.13,.14),M['green'])

def enhance_drive(g):
 M=g['M'];box=g['box'];cy=g['cylinder'];tube=g['tube']
 disc=g['scene'].objects['Service brake disc']
 for j in range(12):
  a=j*math.tau/12;o=box('Brake disc radial slot',(.51*math.cos(a),.51*math.sin(a),.045),(.14,.027,.005),M['green'],disc,.006);o.rotation_euler.z=a
 for x in [-2.50,-2.38,-2.26,-2.14,-2.02,-1.90,-1.78]:cy('Motor cooling fin',(x,0,1.1),.383,.033,M['green'],axis='X')
 cy('Motor fan cover',(-2.66,0,1.1),.385,.11,M['steel'],axis='X')
 for y in [-.23,.23]:box('Motor mounting shoe',(-2.1,y,.69),(1.1,.18,.10),M['steel'])
 box('Drive machine foundation',(-1.4,0,.40),(3.7,2.2,.30),M['cream'])
 for x in [-2.5,-1.8,-1.25,-.7]:
  for y in [-.34,.34]:bolt(g,'Drive foundation bolt',(x,y,.76),.04)
 box('Gearbox inspection cover',(-1.25,.44,1.10),(.62,.028,.40),M['green'])
 for x in [-1.5,-1.0]:
  for z in [.95,1.25]:bolt(g,'Gearbox cover bolt',(x,.466,z),.027,axis='Y')
 cy('Gearbox oil sight glass',(-1.25,.47,1.1),.062,.025,M['glass'],axis='Y')
 tube('Brake hydraulic pipe',[(.3,.8,1.75),(.6,.9,1.75),(.6,.9,.6),(-.9,.9,.6),(-.9,.9,1.05)],.022,M['steel'])
 box('Hydraulic power unit',(-.9,.95,.91),(.56,.50,.50),M['green'])
 for x in [-.34,.34]:bolt(g,'Brake caliper fastener',(x,.915,1.79),.033,axis='Y')
