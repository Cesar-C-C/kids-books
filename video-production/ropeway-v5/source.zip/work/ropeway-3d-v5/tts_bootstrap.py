import os,sys,site,time,json,hashlib,importlib.util,faulthandler
from pathlib import Path
runtime=Path(r'C:\ProgramData\FunCosyVoice3')
sitep=runtime/'.venv/Lib/site-packages'
site.addsitedir(str(sitep))
dlls=[os.add_dll_directory(str(sitep/'torch/lib')),os.add_dll_directory(str(runtime/'.venv/Library/bin'))]
sys.path[:0]=[str(runtime/'CosyVoice'),str(runtime/'CosyVoice/third_party/Matcha-TTS')]
base=Path(__file__).resolve().parent
cache=base/'tts-cache'
os.environ['NUMBA_CACHE_DIR']=str(cache/'numba')
(cache/'numba').mkdir(parents=True,exist_ok=True)
os.environ['TEMP']=str(cache)
os.environ['TMP']=str(cache)
for k,v in {'MPLCONFIGDIR':cache/'matplotlib','HF_HOME':cache/'huggingface','MODELSCOPE_CACHE':cache/'modelscope','XDG_CACHE_HOME':cache,'WETEXT_MODEL_DIR':runtime/'models/wetext'}.items():
    os.environ[k]=str(v)
    if not k=='WETEXT_MODEL_DIR':Path(v).mkdir(parents=True,exist_ok=True)
os.environ['PYTHONUTF8']='1'
os.environ['PYTHONIOENCODING']='utf-8'
import onnxruntime
orig=onnxruntime.SessionOptions
def opts():
    o=orig();o.graph_optimization_level=onnxruntime.GraphOptimizationLevel.ORT_ENABLE_BASIC;o.intra_op_num_threads=2;o.inter_op_num_threads=1;return o
onnxruntime.SessionOptions=opts
spec=importlib.util.spec_from_file_location('shared_synth',runtime/'synthesize.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

