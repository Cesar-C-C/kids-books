"""Use the existing local runtime after the wrapper's uv trampoline failure."""
from pathlib import Path
import json, hashlib, time

B = Path(__file__).resolve().parent
W = B.parent
from tts_bootstrap import runtime, m
data = json.loads((B / 'speech-revisions.json').read_text(encoding='utf8'))
provenance = json.loads((B / 'zh-reference-provenance.json').read_text(encoding='utf8'))
reference = runtime / 'CosyVoice/asset/zero_shot_prompt.wav'
assert hashlib.sha256(reference.read_bytes()).hexdigest() == provenance['reference_sha256']
prompt = 'You are a helpful assistant.<|endofprompt|>' + provenance['transcript']
model = m.AutoModel(model_dir=str(runtime / 'models/Fun-CosyVoice3-0.5B'), fp16=False)
report = []
out = B / 'audio-zh-raw'
out.mkdir(exist_ok=True)
for i, beat in enumerate(data['beats']):
    m.torch.manual_seed(20261004 + i)
    tic = time.time()
    parts = [q['tts_speech'].cpu() for q in model.inference_zero_shot(beat['text'], prompt, str(reference), stream=False)]
    audio = m.torch.cat(parts, dim=1)
    assert m.torch.isfinite(audio).all()
    target = out / (beat['id'] + '.wav')
    m.torchaudio.save(str(target), audio, model.sample_rate, format='wav')
    row = {'id': beat['id'], 'text': beat['text'], 'text_sha256': hashlib.sha256(beat['text'].encode()).hexdigest(),
           'audio_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'mode': 'inference_zero_shot',
           'engine': 'Fun-CosyVoice3-0.5B', 'precision': 'CUDA FP32', 'reference': provenance,
           'seed': 20261004 + i, 'seconds': round(time.time() - tic, 2), **m.validate_wav(target)}
    report.append(row)
    (B / 'new-audio-qa.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(row, ensure_ascii=False), flush=True)
