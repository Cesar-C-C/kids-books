from pathlib import Path
import json, hashlib, zipfile, shutil

B = Path(__file__).resolve().parent
R = B.parents[1]
O = R / 'outputs'
qa = json.loads((B / 'final-qa.json').read_text(encoding='utf8'))
assert qa['ok']

readme = '''# 索道小探险 · 3D配音修订版 v5

5–8岁；横屏1920×1080 / 24fps；9分57.5秒；104组中英双语字幕；普通话与英语可切换。

## 此次修订

- 约2:37：中文配音中的“行走轮”连续读出，保留原字幕。
- 约8:32：中文配音中的“不故意”连续读出，保留原字幕。
- 约8:38：“担心什么？”改为“如果担心，”，中文配音与字幕同步修改。

实际句子起点仍为154.5374、510.05897、514.70917秒。用户标记的是听到相关词组的附近时间。
旁白时间线保持不变。英文配音母版和模型库逐字节保留；画面沿用v4，只重新合成包含更正字幕的20.833秒区间。其余13840帧的图像编码内容经过对比保留。
中文母版先解码，在三个原句时间窗内替换，再整体编码为AAC；重新编码前，窗外PCM逐样本一致，编码后不宣称样本逐字节一致。

中文采用已有Fun-CosyVoice3-0.5B、CUDA FP32及原片官方示例参考声音。参考WAV的哈希及准确文本见zh-reference-provenance.json。
初次生成的“不故意”仍在“不”后出现停顿，没有采用该候选。为保持连读，采用含“我们”语境前缀的候选，从波形及词时间边界裁掉该前缀；最终输出只有指定句子，ASR检查不含“我们”。前缀只用于合成，未加入字幕或成片配音。
音量与原句匹配并限制短暂峰值；第二句采用约1.037倍保调变速，其余两句不变速。三个成片句子均落在原时间窗内，不移动后续镜头。

## 文件与重新生成

annotations.py、compose_film.py：v4的内容标记和字幕样式；新译文来自full-timing.json。
speech-revisions.json：三处修订的指定文字、旧文、字幕、时间窗与关键词。
audio-zh-raw / audio-zh-prepared：合成候选及最终句子WAV。
narration-zh.m4a / narration-en.m4a：成片两种配音母版，无需再次合成即可重建视频。
patch_audio.py、patch_picture.py、deliver_revisions.py：本机对v4的音频、局部画面及完整交付的修改流程，需要同机v4文件。
synthesize_revisions.py、refine_compound.py：复现本次中文合成的参数，依赖已有共享运行时。
check_revised_speech.py：本地Whisper small的词时间核查；识别结果存在部分同音字替代，不作为人工听感验收。
verify_speech_delivery.py、final-qa.json：成片解码、旧版哈希、字幕唯一改动、时间线和真实浏览器检查记录。

完整重建不需要v4文件或重新合成配音：保持压缩包目录结构，在解压根目录运行

```powershell
python work/ropeway-3d-v5/render_project.py --blender "C:/Program Files/Blender Foundation/Blender 5.2/blender.exe" --ffmpeg "C:/path/to/ffmpeg.exe"
```

需要Blender5.2、Python3.11+、NumPy、Pillow、支持libass/minterpolate/libx264的FFmpeg，以及Microsoft YaHei与Segoe UI字体。重新合成语音使用现有的Python3.10与Fun-CosyVoice运行时，不属于重建视频的必要步骤。
继承v3/v4的镜头来源：关键运行镜头原生24fps，部分讲解镜头720p/8fps经运动补偿输出24fps；本次没有重新建模或提升这些原始镜头分辨率。

## 模型说明与验收范围

模型为通用原理示意，结构、比例、剖视和动作速度经过教学简化。中间站展示两段独立绳环、同一吊厢经轨道输送到下一段的案例；具体设备以运营方说明为准。类型对比和局部往返观察镜头仅作教学示例。
本次核查包括词内时间连续性、ASR关键词与前缀删除、音量与时间窗、成片字幕、整片解码和17项浏览器播放检查。没有新增人工听音或实体设备验收。
旧的2D、3D v1、v2、v3和v4产物均保留；它们不在此包中被覆盖。
'''
(B / 'README.md').write_text(readme, encoding='utf8')

names = ['README.md', 'EDITORIAL-REVIEW.md', 'editorial-audit.json', 'annotation-plan.json',
         'annotations.py', 'ropeway_scene.py', 'film_models.py', 'enhance.py', 'overview.py',
         'intermediate.py', 'motion.py', 'render_animation.py', 'render_baseline.py',
         'compose_film.py', 'render_project.py', 'full-timing.json', 'sources.json', 'film.ass',
         'ropeway-model-library.blend', 'grip-camera-animation.blend', 'narration-en.m4a',
         'narration-zh.m4a', 'speech-revisions.json', 'zh-reference-provenance.json',
         'new-audio-qa.json', 'context-candidate.json', 'speech-asr-review.json',
         'speech-asr-context.json', 'speech-asr-final.json', 'audio-patch-qa.json',
         'video-patch-qa.json', 'correction-visual-qa.json', 'full-player-qa.json', 'final-qa.json',
         'preserved.json', 'render-progress.json', 'synthesize_revisions.py', 'refine_compound.py', 'tts_bootstrap.py',
         'check_revised_speech.py', 'patch_audio.py', 'patch_picture.py', 'deliver_revisions.py',
         'verify_player.cjs', 'verify_speech_delivery.py', 'package_speech_delivery.py']
with zipfile.ZipFile(O / 'ropeway-3d-v5-source.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name in names:
        z.write(B / name, 'work/ropeway-3d-v5/' + name)
    for pattern in ['*-anchors.json', '*-motion.json']:
        for p in B.glob(pattern):
            z.write(p, 'work/ropeway-3d-v5/' + p.name)
    for folder in ['audio-zh-raw', 'audio-zh-prepared']:
        for p in (B / folder).glob('*.wav'):
            if p.name.endswith(('-trim.wav', '-tempo.wav', '-limited.wav')):
                continue
            z.write(p, 'work/ropeway-3d-v5/' + folder + '/' + p.name)
    z.write(R / 'work/bilingual-player-template.html', 'work/bilingual-player-template.html')
with zipfile.ZipFile(O / 'ropeway-3d-v5-source.zip') as z:
    assert z.testzip() is None
shutil.copy2(B / 'final-qa.json', O / 'ropeway-3d-v5-qa.json')
guide = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>索道小探险 · v5配音修订</title><style>body{margin:0;background:#f6f1e4;color:#183c35;font:18px/1.8 "Segoe UI","Microsoft YaHei",sans-serif}main{max-width:1100px;margin:auto;padding:30px 22px}h1{line-height:1.3}video,img{width:100%;border-radius:14px}a{color:#ad5328}.links{display:flex;gap:14px;flex-wrap:wrap;margin:25px 0}.links a{background:#183c35;color:#fff;padding:10px 16px;border-radius:10px;text-decoration:none}table{border-collapse:collapse;width:100%}td,th{padding:14px 10px;text-align:left;border-bottom:1px solid #c9d3c4}.small{font-size:15px;color:#426974}</style><main><h1>索道小探险 · v5配音修订</h1><p>9分57.5秒 · 横屏 · 中英双语字幕与可切换配音</p><div class="links"><a href="ropeway-3d-v5-watch.html">观看完整新版</a><a href="ropeway-3d-v5.mp4">双音轨MP4</a><a href="ropeway-3d-v5-source.zip">模型与源码</a><a href="ropeway-3d-v4-watch.html">保留的v4</a></div><table><tr><th>附近时间</th><th>修订</th></tr><tr><td>2:37</td><td>“行走轮”连续读出，保留原字幕。</td></tr><tr><td>8:32</td><td>“不故意”连续读出，保留原字幕。</td></tr><tr><td>8:38</td><td>中文配音与字幕同步改为“如果担心，告诉大人，按标示的指引联系工作人员。”</td></tr></table><h2>三处修订预览</h2><video controls preload="metadata" poster="ropeway-3d-v5-corrections-preview.jpg" src="ropeway-3d-v5-corrections-preview.mp4"></video><p class="small">约23秒，使用新版成片的普通话音轨，包含进站句和两句乘坐提示。原片时间线、英语配音及其余讲解内容保留。</p><img src="ropeway-3d-v5-subtitle-correction.jpg" alt="新版成片中如果担心的中英字幕"><h2>验证记录</h2><p class="small">已检查最终WAV的关键词、词内停顿与前缀删除、音量和原句时间窗；核对成片字幕与画面衔接，完成整片音视频解码和17项真实浏览器播放检查。中文只替换三个句子后重新编码，英文母版逐字节保留。自动识别及时间检查不等于人工听感验收。<a href="ropeway-3d-v5-qa.json">查看记录</a></p></main></html>'''
(O / 'ropeway-3d-v5-guide.html').write_text(guide, encoding='utf8')
manifest = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in O.glob('ropeway-3d-v5*') if p.is_file() and p.name != 'ropeway-3d-v5-manifest.json'}
(O / 'ropeway-3d-v5-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
print('Packaged', len(manifest), 'v5 artifacts.')
