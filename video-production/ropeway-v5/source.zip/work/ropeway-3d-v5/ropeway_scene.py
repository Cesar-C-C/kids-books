"""Original, parameterized teaching model. Blender 5.2 / EEVEE.
The straight station segment is simplified and not an engineering drawing.
Coordinates in metres: X travel, Y lateral separation, Z height.
"""
import bpy,math,json,time,sys
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
ARGS=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
def option(name,default):
 return ARGS[ARGS.index(name)+1] if name in ARGS else default
MODE=option('--mode','preview');SIZE=int(option('--width','1280'));SAMPLES=int(option('--samples','16'))
FPS=24;ROPE_Z=4.08;WHEEL_R=.19;RAIL_TOP=3.95;WHEEL_Z=RAIL_TOP+WHEEL_R
S12=16.24108333333332;S13=14.62070833333334;S14=13.599
TOTAL=S12+S13+S14
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
if hasattr(bpy.context.preferences.filepaths,'use_save_preview'):
 bpy.context.preferences.filepaths.use_save_preview=False
for engine in ['BLENDER_EEVEE','BLENDER_EEVEE_NEXT']:
 try:scene.render.engine=engine;break
 except TypeError:continue
if hasattr(scene,'eevee'):
 for prop in ['taa_render_samples','taa_samples']:
  if hasattr(scene.eevee,prop):setattr(scene.eevee,prop,SAMPLES)
 if hasattr(scene.eevee,'use_raytracing'):scene.eevee.use_raytracing=False
scene.render.resolution_x=SIZE;scene.render.resolution_y=round(SIZE*9/16);scene.render.resolution_percentage=100
scene.render.fps=FPS;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB'
scene.render.film_transparent=False
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.25
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.78,.82,.74,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65
scene.unit_settings.system='METRIC'
def mat(name,color,metal=0,rough=.45):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m
M={
 'cream':mat('Warm cream',(0.87,.82,.69)),
 'green':mat('Forest enamel',(.032,.14,.10),.25),
 'sage':mat('Sage station',(.36,.54,.42)),
 'orange':mat('Orange cabin',(.85,.23,.055),.15,.32),
 'rail':mat('Supporting rail',(.07,.39,.24),.45,.28),
 'steel':mat('Machined steel',(.34,.43,.44),.72,.28),
 'rubber':mat('Rubber wheels',(.021,.028,.025),0,.62),
 'glass':mat('Blue glass',(.12,.32,.38),.45,.18),
 'spring':mat('Visible springs',(.81,.60,.12),.65,.25),
 'white':mat('Ivory trim',(.91,.91,.79),.1,.35),
 'floor':mat('Warm ground',(.80,.79,.66)),
}
def parent(obj,par):
 if par:obj.parent=par
 return obj
def empty(name,loc=(0,0,0),par=None):
 o=bpy.data.objects.new(name,None);scene.collection.objects.link(o);o.location=loc;parent(o,par);return o
def finish(o,name,material,par=None):
 o.name=name;o.data.materials.append(material);parent(o,par)
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=True
 return o
def box(name,loc,size,material,par=None,bevel=.035):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=size
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,name,material,par)
 if bevel:
  mod=o.modifiers.new('Soft manufactured edges','BEVEL');mod.width=bevel;mod.segments=3
  n=o.modifiers.new('Stable surface normals','WEIGHTED_NORMAL')
 return o
def cylinder(name,loc,radius,depth,material,par=None,axis='Z',vertices=32):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc)
 o=finish(bpy.context.object,name,material,par)
 if axis=='Y':o.rotation_euler[0]=math.pi/2
 if axis=='X':o.rotation_euler[1]=math.pi/2
 bevel=o.modifiers.new('Rounded rim','BEVEL');bevel.width=min(.016,radius*.1);bevel.segments=2
 return o
def tube(name,points,radius,material,par=None):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=radius;c.bevel_resolution=3
 s=c.splines.new('POLY');s.points.add(len(points)-1)
 for q,p in zip(s.points,points):q.co=(*p,1)
 o=bpy.data.objects.new(name,c);scene.collection.objects.link(o);finish(o,name,material,par);return o
def torus(name,loc,radius,minor,material,par=None,axis='Y'):
 bpy.ops.mesh.primitive_torus_add(major_radius=radius,minor_radius=minor,major_segments=32,minor_segments=8,location=loc)
 o=finish(bpy.context.object,name,material,par)
 if axis=='Y':o.rotation_euler[0]=math.pi/2
 if axis=='X':o.rotation_euler[1]=math.pi/2
 return o
def smooth(a,b,t):
 x=max(0,min(1,(t-a)/(b-a)));return x*x*(3-2*x)
def lane_y(x):return .75*smooth(-5,-2.5,x)*(1-smooth(.1,1.8,x))
def lane_angle(x):return math.atan2(lane_y(x+.005)-lane_y(x-.005),.01)
carrier=empty('Carrier_and_cabin')
for x in [-.41,.41]:box('Carrier side beam',(x,0,4.24),(.12,1.1,.13),M['steel'],carrier)
for y in [-.5,.5]:box('Carrier cross beam',(0,y,4.24),(.92,.12,.13),M['steel'],carrier)
box('Tire friction plate',(0,-.24,4.46),(1.06,.34,.095),M['rubber'],carrier)
running=[]
for x in [-.31,.31]:
 for y in [-.62,.62]:
  hub=empty('Running_wheel_pivot',(x,y,WHEEL_Z),carrier);running.append(hub)
  cylinder('Running wheel',(0,0,0),WHEEL_R,.13,M['rubber'],hub,'Y')
  cylinder('Wheel hub',(0,.075 if y>0 else -.075,0),.075,.022,M['steel'],hub,'Y')
  box('Wheel rotation mark',(0,.09 if y>0 else -.09,0),(.022,.016,.22),M['white'],hub,.004)
# A rigid hanger connects the cabin to its carrier.
tube('Rigid cabin hanger',[(-.23,0,4.16),(-.23,0,3.56),(.10,0,2.87),(.10,0,2.65)],.072,M['green'],carrier)
cylinder('Hanger pivot',(-.23,0,4.16),.11,.40,M['steel'],carrier,'Y')
box('Orange lower cabin',(0,0,1.22),(1.76,1.46,.70),M['orange'],carrier,.16)
box('Cabin floor',(0,0,.82),(1.85,1.53,.17),M['green'],carrier,.09)
box('Cabin roof',(0,0,2.57),(1.90,1.61,.17),M['white'],carrier,.10)
for x in [-.77,.77]:
 for y in [-.60,.60]:box('Window pillar',(x,y,2.03),(.12,.12,1.01),M['orange'],carrier,.03)
for y in [-.705,.705]:
 for x in [-.43,.43]:
  box('Cabin side glass',(x,y,2.05),(.71,.047,.87),M['glass'],carrier,.075)
 box('Closed door centre',(0,y*1.022,2.02),(.045,.035,1.04),M['white'],carrier,.012)
 box('Door handle',(.10,y*1.043,1.77),(.025,.036,.18),M['white'],carrier,.01)
for x in [-.872,.872]:box('Cabin end glass',(x,0,2.05),(.047,1.12,.87),M['glass'],carrier,.075)
# Fixed and moving jaws around the rope. The moving jaw and actuator are one assembly.
moving=empty('Moving_grip_jaw',(0,0,0),carrier)
for x in [-.18,.18]:
 tube('Fixed grip contact jaw',[(x,.080*math.cos(a),ROPE_Z+.080*math.sin(a)) for a in [math.pi/2+i*math.pi/20 for i in range(21)]],.037,M['steel'],carrier)
 tube('Moving grip contact jaw',[(x,.080*math.cos(a),ROPE_Z+.080*math.sin(a)) for a in [-math.pi/2+i*math.pi/20 for i in range(21)]],.037,M['orange'],moving)
box('Fixed jaw bridge',(0,-.105,ROPE_Z),(.44,.06,.075),M['steel'],carrier,.015)
box('Moving jaw bridge',(0,.105,ROPE_Z),(.44,.06,.075),M['orange'],moving,.015)
box('Coupling lever',(0,.24,4.31),(.28,.45,.095),M['steel'],moving,.04)
cylinder('Actuator roller',(0,.46,4.37),.095,.11,M['rubber'],moving,'X')
springs=[]
for x in [-.24,.24]:
 points=[(x+.075*math.cos(i*math.tau/28),-.50+i/(10*28)*.54,4.38+.075*math.sin(i*math.tau/28)) for i in range(10*28+1)]
 spring=tube('Parallel compression spring',points,.015,M['spring'],carrier);springs.append(spring)
 cylinder('Spring fixed seat',(x,-.52,4.38),.11,.038,M['steel'],carrier,'Y')
box('Fixed spring bridge',(0,-.54,4.38),(.67,.10,.13),M['steel'],carrier)
from enhance import enhance_carrier, enhance_station
enhance_carrier(globals())
# Rail top and wheel contact positions share the same height by construction.
rails=[]
for side in [-1,1]:
 pts=[(-6.8+i*12.5/140,lane_y(-6.8+i*12.5/140)+side*.62,RAIL_TOP-.047) for i in range(141)]
 rails.append(tube('Load-bearing station rail',pts,.047,M['rail']))
for x in [-6,-3,0,3,5.3]:
 for side in [-1,1]:
  y=lane_y(x)+side*.86
  # Foreground supports are cut away to keep the load path visible.
  if side<0:box('Station support column',(x,y,1.9),(.13,.13,3.8),M['sage'])
  box('Rail support bracket',(x,lane_y(x)+side*.72,3.83),(.15,.35,.12),M['steel'])
 box('Station overhead support',(x,lane_y(x)-.90,4.85),(.15,.50,.15),M['sage'])
box('Boarding platform',(-.2,1.99,.54),(5.3,1.7,.24),M['sage'],bevel=.12)
for x in [-2.5,-1.5,-.5,.5,1.5]:box('Platform edge marker',(x,1.17,.68),(.52,.10,.025),M['white'],bevel=.006)
# Independent steel rope and moving stripes, represented as teaching motion marks.
rope=cylinder('Continuous steel rope',(0,0,ROPE_Z),.042,28,M['steel'],axis='X',vertices=20)
rope_mat=mat('Moving steel-rope surface',(.27,.34,.33),.75,.38);rope.data.materials.clear();rope.data.materials.append(rope_mat)
nodes=rope_mat.node_tree.nodes;links=rope_mat.node_tree.links
coord=nodes.new('ShaderNodeTexCoord');mapping=nodes.new('ShaderNodeMapping');wave=nodes.new('ShaderNodeTexWave');ramp=nodes.new('ShaderNodeValToRGB')
wave.bands_direction='Z';wave.inputs['Scale'].default_value=38;wave.inputs['Distortion'].default_value=0
ramp.color_ramp.elements[0].position=.22;ramp.color_ramp.elements[0].color=(.025,.05,.045,1)
ramp.color_ramp.elements[1].position=.62;ramp.color_ramp.elements[1].color=(.51,.60,.54,1)
links.new(coord.outputs['Generated'],mapping.inputs['Vector']);links.new(mapping.outputs['Vector'],wave.inputs['Vector']);links.new(wave.outputs['Color'],ramp.inputs['Fac']);links.new(ramp.outputs['Color'],nodes.get('Principled BSDF').inputs['Base Color'])
tires=[]
def tire_speed(x):
 if x<-4.1:return .5
 if x<-1.78:return math.sqrt(max(.22**2,.25-2*(.28/(S12-9.8))*(x+4.1)))
 if x<1.44:return .22
 if x<3.20:return math.sqrt(.22**2+2*(.28/4.885)*(x-1.44))
 return .5
for i in range(22):
 x=-5.4+i*.50;hub=empty('Conveyor_tire_pivot',(x,lane_y(x)-.24,4.7655));tires.append((hub,tire_speed(x)))
 torus('Station conveyor tire',(0,0,0),.19,.068,M['rubber'],hub)
 cylinder('Conveyor tire hub',(0,.075,0),.10,.025,M['steel'],hub,'Y')
 for a in [0,math.pi/2]:
  spoke=box('Conveyor hub spoke',(0,.09,0),(.025,.02,.17),M['white'],hub,.003);spoke.rotation_euler[1]=a
box('Ground',(0,0,-.20),(200,200,.25),M['floor'],bevel=0)
def area(name,loc,power,size,color):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;o.rotation_euler=(Vector((0,0,2))-o.location).to_track_quat('-Z','Y').to_euler()
area('Warm daylight',(-6,5,11),1500,8,(1,.91,.76));area('Soft sky fill',(3,-7,8),1100,7,(.76,.88,1))
bpy.ops.object.camera_add(location=(-7,10,7));cam=bpy.context.object;cam.name='Teaching_camera';cam.data.type='ORTHO';cam.data.lens=48;cam.data.clip_end=300;scene.camera=cam
enhance_station(globals())

def position(t):
 if t<9.8:return -9+.5*t,.5
 if t<S12:
  u=t-9.8;a=-.28/(S12-9.8);return -4.1+.5*u+.5*a*u*u,.5+a*u
 x12=-4.1+.36*(S12-9.8)
 if t<S12+S13:return x12+.22*(t-S12),.22
 u=t-S12-S13;acc=.28/4.885;x0=x12+.22*S13
 if u<4.885:return x0+.22*u+.5*acc*u*u,.22+acc*u
 return x0+.22*4.885+.5*acc*4.885**2+.5*(u-4.885),.5
def state(t):
 x,v=position(t);op=smooth(5.445,7.3,t)*(1-smooth(S12+S13+4.885,S12+S13+7.98,t))
 y=lane_y(x);yaw=lane_angle(x)
 support=(-6.8+.31<=x<=5.7-.31)
 closed=op<.015
 return {'time':t,'x':x,'y':y,'speed':v,'rope_speed':.5,'opening':op,'rail_support':support,'grip_closed':closed,'weight_supported':support or closed}
# The stationary guide pushes the actuator roller outward. Its falling edge
# releases the roller so the compressed springs can close the jaw.
guide=[]
for i in range(201):
 t=5.445+(S12+S13+7.98-5.445)*i/200;q=state(t);yaw=lane_angle(q['x']);r=.46+.40*q['opening']
 guide.append((q['x']-math.sin(yaw)*r,q['y']+math.cos(yaw)*r-.120,4.37))
tube('Station opening and closing guide',guide,.025,M['spring'])
for i in [12,45,80,120,160,190]:
 x,y,z=guide[i];tube('Opening guide mounting',[(x,y-.16,4.78),(x,y-.16,z),(x,y,z)],.023,M['steel'])
def set_time(t):
 q=state(t);carrier.location=(q['x'],q['y'],0);carrier.rotation_euler[2]=lane_angle(q['x'])
 moving.location.y=.40*q['opening']
 # The external opening mechanism compresses the spring; release lets it close.
 for sp in springs:sp.scale.y=1-.22*q['opening'];sp.location.y=-.11*q['opening']
 for i,hub in enumerate(running):
  dx=[-.31,-.31,.31,.31][i];dy=[-.62,.62,-.62,.62][i];wx=q['x']+dx;wy=lane_y(wx)+dy
  yaw=lane_angle(q['x']);rx=wx-q['x'];ry=wy-q['y']
  hub.location=(rx*math.cos(yaw)+ry*math.sin(yaw),-rx*math.sin(yaw)+ry*math.cos(yaw),WHEEL_Z)
  hub.rotation_euler=(0,-q['x']/WHEEL_R,lane_angle(wx)-yaw)
 for hub,v in tires:hub.rotation_euler[1]=-t*v/.258
 mapping.inputs['Location'].default_value[2]=-t*.5/28
 # Follow the carrier, with a deliberately visible close-up of rail/grip transfer.
 if t<S12:
  close=smooth(1.5,3.5,t)*(1-smooth(8.3,11.3,t));target=Vector((q['x'],q['y'],2.65+1.57*close));scale=10.3-6.3*close
  offset=Vector((-4.3+2.5*close,8-3.0*close,3.8-2.8*close))
 elif t<S12+S13:
  target=Vector((q['x']+.2,q['y'],2.65));scale=10.3;offset=Vector((-5.5,9,3.8))
 else:
  u=t-S12-S13;close=smooth(3.0,4.6,u)*(1-smooth(8.6,10.4,u));target=Vector((q['x'],q['y'],2.7+1.52*close));scale=10.3-6.3*close;offset=Vector((3.7-2*close,8-3*close,3.8-2.8*close))
 cam.location=target+offset;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale
 if not globals().get('BAKING',False):bpy.context.view_layer.update()
 return q

def verify_mechanics():
 states=[state(i/FPS) for i in range(math.ceil(TOTAL*FPS))]
 tests={
  'continuous_support':all(s['weight_supported'] for s in states),
  'opening_only_on_rails':all(s['rail_support'] for s in states if s['opening']>.015),
  'closed_grip_aligned_with_rope':all(abs(s['y'])<.003 for s in states if s['grip_closed']),
  'closed_grip_matches_rope_speed':all(abs(s['speed']-.5)<.003 for s in states if s['grip_closed']),
  'wheel_contact_height':abs(WHEEL_Z-WHEEL_R-RAIL_TOP)<1e-8,
  'tire_contact_height':abs(4.7655-.258-(4.46+.095/2))<1e-8,
  'jaw_rope_clearance_mm':abs((.080-.037)-.042)*1000,
  'closed_before_rail_exit':state(40.2)['grip_closed'],
 }
 assert all(v for k,v in tests.items() if not k.endswith('_mm')),tests
 (BASE/'mechanical-qa.json').write_text(json.dumps({'frames':len(states),'tests':tests,'units':'metres; model speeds are slowed for teaching','model_scope':'generic teaching mechanism, not manufacturer CAD'},indent=2),encoding='utf8')

def bake_animation():
 scene.frame_start=1;scene.frame_end=math.ceil(TOTAL*FPS)
 for f in range(scene.frame_start,scene.frame_end+1):
  set_time((f-1)/FPS)
  for o in [carrier,moving,cam]+springs+running+[h for h,v in tires]:
   for path in ['location','rotation_euler','scale']:o.keyframe_insert(data_path=path,frame=f)
  cam.data.keyframe_insert(data_path='ortho_scale',frame=f)
  mapping.inputs['Location'].keyframe_insert(data_path='default_value',frame=f)
 set_time(0);scene.frame_set(1)
 bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'station-animated.blend'))

def render_sequence():
 verify_mechanics();bake_animation();dest=BASE/'pilot-frames';dest.mkdir(exist_ok=True)
 report={'total_frames':math.ceil(TOTAL*FPS),'rendered':0,'started':time.time(),'width':SIZE,'samples':SAMPLES}
 for f in range(report['total_frames']):
  target=dest/f'{f:05d}.png'
  scene.frame_set(f+1);set_time(f/FPS);scene.render.filepath=str(target)
  if not target.exists():bpy.ops.render.render(write_still=True)
  report['rendered']=f+1;report['elapsed_seconds']=time.time()-report['started']
  if f%24==0 or f==report['total_frames']-1:(BASE/'pilot-render-progress.json').write_text(json.dumps(report),encoding='utf8')
 (BASE/'pilot-render-done.json').write_text(json.dumps(report),encoding='utf8')
def preview():
 dest=BASE/'previews';dest.mkdir(exist_ok=True);report=[]
 for t in [float(v) for v in option('--times','1.0,5.8,8.5,12.0,22.0,36.8,40.0,44.2').split(',')]:
  q=set_time(t);scene.render.filepath=str(dest/f't{t:05.1f}.png');tic=time.perf_counter();bpy.ops.render.render(write_still=True);q['render_seconds']=time.perf_counter()-tic;report.append(q)
 (BASE/'preview-report.json').write_text(json.dumps({'engine':scene.render.engine,'resolution':[SIZE,scene.render.resolution_y],'samples':SAMPLES,'objects':len(scene.objects),'states':report},indent=2),encoding='utf8')
 bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'station-draft.blend'))
if MODE=='preview':preview()
elif MODE=='render':render_sequence()
elif MODE=='verify':verify_mechanics()
