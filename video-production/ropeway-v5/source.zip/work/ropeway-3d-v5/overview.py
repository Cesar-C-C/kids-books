"""A continuous detachable circuit. Station speed is lower; no cabin is hidden."""
import math,bisect,json
from pathlib import Path
import bpy

def build_network(g):
 E=g['empty'];box=g['box'];cy=g['cylinder'];tube=g['tube'];tor=g['torus'];M=g['M'];smooth=g['smooth'];look=g['look']
 X=12;R=3;TURN=4.2;L=48+2*math.pi*TURN
 def sag_shape(x):
  # The rope rests on the whole six-sheave bank; sag lies between supports.
  a=abs(x)
  return math.sin(math.pi*(a-1.95)/(7.2-1.95))**2 if 1.95<a<7.2 else 0
 def path(s):
  s%=L
  if s<24:
   x=-12+s;y=-3-1.2*smooth(8,12,abs(x));a=math.atan2(((-3-1.2*smooth(8,12,abs(x+.001)))-(-3-1.2*smooth(8,12,abs(x-.001)))),.002)
  elif s<24+math.pi*TURN:
   a0=-math.pi/2+(s-24)/TURN;x=12+TURN*math.cos(a0);y=TURN*math.sin(a0);a=a0+math.pi/2
  elif s<48+math.pi*TURN:
   x=12-(s-24-math.pi*TURN);y=3+1.2*smooth(8,12,abs(x));a=math.pi+math.atan2(((3+1.2*smooth(8,12,abs(x+.001)))-(3+1.2*smooth(8,12,abs(x-.001)))),.002)
  else:
   a0=math.pi/2+(s-48-math.pi*TURN)/TURN;x=-12+TURN*math.cos(a0);y=TURN*math.sin(a0);a=a0+math.pi/2
  # A shallow line sag; station rope/rail contact remains at z=4.08.
  sag=.11*sag_shape(x)
  return x,y,a,4.08-sag
 N=1800;ss=[i*L/N for i in range(N+1)];tt=[0.]
 for i in range(N):
  p=path(ss[i]);q=path(ss[i+1]);x=(abs(p[0])+abs(q[0]))/2
  v=.62-(.62-.14)*smooth(8.1,11.7,x)
  d=math.hypot(q[0]-p[0],q[1]-p[1]);tt.append(tt[-1]+d/v)
 period=tt[-1]
 def at(t,details=False):
  t%=period;i=min(N-1,bisect.bisect_right(tt,t)-1);s=ss[i]+(ss[i+1]-ss[i])*(t-tt[i])/(tt[i+1]-tt[i]);return (path(s),s) if details else path(s)
 def rope_path():
  points=[]
  for i in range(121):
   x=-12+24*i/120;z=4.08-.11*sag_shape(x);points.append((x,-3,z))
  for i in range(65):a=-math.pi/2+math.pi*i/64;points.append((12+3*math.cos(a),3*math.sin(a),4.08))
  for i in range(121):
   x=12-24*i/120;z=4.08-.11*sag_shape(x);points.append((x,3,z))
  for i in range(65):a=math.pi/2+math.pi*i/64;points.append((-12+3*math.cos(a),3*math.sin(a),4.08))
  return points
 cable_points=rope_path();cable=tube('Continuous steel rope circuit',cable_points,.042,M['steel'])
 w1=g['model_wheel'](-12,0,4.08,3);w2=g['model_wheel'](12,0,4.08,3)
 conveyor_hubs=[]
 for side in [-1,1]:
  center=12*side
  box('Station foundation',(center,0,.17),(9.9,10.3,.32),M['cream'],bevel=.20)
  box('Station slow boarding island',(center,0,.56),(8.3,5.8,.32),M['sage'],bevel=.16)
  for x in [center-3.4,center,center+3.4]:
   box('Station rear column',(x,-5.20,2.95),(.23,.23,5.2),M['green'])
   box('Station roof spine',(x,-4.75,5.56),(.24,1.1,.22),M['steel'])
   box('Station roof cutaway strip',(x,-4.76,5.72),(2.6,1.15,.15),M['cream'],bevel=.08)
  box('Station rear glass wall',(center,-5.34,2.48),(7.5,.035,3.6),M['glass'],bevel=.045)
  for x in [center-3.4,center-1.7,center,center+1.7,center+3.4]:box('Wall window mullion',(x,-5.34,2.48),(.06,.07,3.65),M['green'])
  # Both paired rails continue around the station, away from the turning rope.
  pts=[path(i*L/540) for i in range(541) if side*path(i*L/540)[0]>=6.6]
  if side<0:
   full=[path(i*L/540) for i in range(541)]
   pts=[p for i,p in enumerate(full) if i*L/540>L/2 and p[0]<=-6.6]+[p for i,p in enumerate(full) if i*L/540<L/2 and p[0]<=-6.6]
  for dy in [-.62,.62]:
   tube('Terminal carrier support rail',[(x-math.sin(a)*dy,y+math.cos(a)*dy,3.903) for x,y,a,z in pts],.047,M['rail'])
  for j,p in enumerate(pts[::5]):
   x,y,a,z=p;h=E('Terminal tire conveyor',(x+math.sin(a)*.24,y-math.cos(a)*.24,4.7655));h.rotation_euler.z=a
   conveyor_hubs.append((h,.62-(.62-.14)*smooth(8.1,11.7,abs(x))))
   tor('Terminal conveyor tire',(0,0,0),.19,.068,M['rubber'],h)
   cy('Terminal conveyor hub',(0,.08,0),.09,.025,M['steel'],h,'Y')
   box('Terminal tire axle mount',(0,-.23,0),(.12,.27,.12),M['steel'],h,.02)
   if j%3==0:
    tube('Terminal rail bracket',[(x,y,3.78),(x-math.sin(a)*.85,y+math.cos(a)*.85,3.78)],.035,M['steel'])
  # Fixed guide opens the grip after the rails take the load.
  tube('Terminal grip opening guide',[(x-math.sin(a)*(.34+.40*smooth(7.2,7.9,abs(x))),y+math.cos(a)*(.34+.40*smooth(7.2,7.9,abs(x))),4.37) for x,y,a,z in pts],.025,M['spring'])
  for y in [-2.80,2.80]:tube('Boarding platform edge stripe',[(center-3.2,y,.728),(center+3.2,y,.728)],.022,M['spring'])
 # Detailed drive housing is recognizable in the close-up and overview.
 cy('Main electric drive motor',(-12,0,1.62),.53,1.6,M['green'],axis='X')
 for x in [-12.6,-12.4,-12.2,-12,-11.8,-11.6]:cy('Main motor cooling ring',(x,0,1.62),.57,.05,M['green'],axis='X')
 box('Main drive gearbox',(-10.7,0,1.65),(1.4,1.2,1.0),M['sage'],bevel=.14)
 cy('Main drive coupling',(-11.25,0,1.62),.16,.66,M['steel'],axis='X')
 tension=box('Wheel tension carriage',(12,0,.78),(2.4,1.45,.25),M['steel'])
 for y in [-.62,.62]:box('Tension carriage guide',(13.1,y,.61),(4.2,.13,.17),M['steel'])
 cy('Hydraulic tension barrel',(14.4,0,.91),.22,1.3,M['green'],axis='X')
 ram=cy('Hydraulic tension rod',(13.25,0,.91),.09,1.35,M['steel'],axis='X')
 # A line tower supports each side; foundations, crosshead and roller axles stay connected.
 for y in [-3,3]:
  box('Line tower concrete base',(0,y-1.35,.16),(1.2,1.3,.34),M['cream'])
  box('Line tower mast',(0,y-1.35,1.85),(.48,.53,3.3),M['sage'],bevel=.075)
  tube('Line tower cantilever bracket',[(0,y-1.35,3.2),(0,y-.38,3.46)],.14,M['steel'])
  box('Line tower crosshead',(0,y-.38,3.46),(4.4,.30,.19),M['steel'])
  for x in [-1.8,-1.08,-.36,.36,1.08,1.8]:
   tor('Line supporting sheave',(x,y,3.808),.195,.035,M['rubber']);cy('Line sheave bearing',(x,y+.08,3.808),.08,.12,M['steel'],axis='Y')
   box('Line sheave bearing mount',(x,y-.38,3.704),(.21,.26,.30),M['green'])
   cy('Line sheave supporting axle',(x,y-.18,3.808),.045,.42,M['steel'],axis='Y')
 cars=[];jaws=[];coils=[];running=[];car_nodes=[]
 for i in range(12):
  p=g['copy_tree'](g['carrier']);p.name=f'Continuous_cabin_{i:02d}';p['asset_id']='explorer-cabin-v2';cars.append(p)
  ch=g['descend'](p);car_nodes.append(ch);jaws.append(next(o for o in ch if o.name.startswith('Moving_grip_jaw')));coils.append([o for o in ch if o.name.startswith('Parallel compression spring')]);running.append([o for o in ch if o.name.startswith('Running_wheel_pivot')])
 forest=[]
 for i in range(28):
  x=-15+(i%14)*2.3;y=(-8.2 if i<14 else 7.1)+.43*math.sin(i)
  forest.append(cy('Conifer trunk',(x,y,.68),.075,1.25,M['green']))
  for z,r in [(1.10,.68),(1.49,.53),(1.88,.37)]:
   bpy.ops.mesh.primitive_cone_add(vertices=16,radius1=r,radius2=.035,depth=1.07,location=(x,y,z));o=bpy.context.object;o.name='Conifer branches';o.data.materials.append(M['sage'] if i%3 else M['green']);forest.append(o)
 for y in [-13,-18]:
  verts=[];faces=[];NX=46;NY=10
  for j in range(NY):
   for i in range(NX):
    x=-25+i*50/(NX-1);yy=y+j*5/(NY-1);z=max(-.1,(.8+.7*math.sin(x*.22+.8))*math.sin(j/(NY-1)*math.pi)*2.6)
    verts.append((x,yy,z))
  for j in range(NY-1):
   for i in range(NX-1):n=j*NX+i;faces.append((n,n+1,n+NX+1,n+NX))
  mesh=bpy.data.meshes.new('Rolling forest terrain');mesh.from_pydata(verts,[],faces);mesh.materials.append(M['sage']);o=bpy.data.objects.new('Distant hills',mesh);g['scene'].collection.objects.link(o);forest.append(o)
  for p in mesh.polygons:p.use_smooth=True
 start=tt[min(N,round(17/L*N))]
 def update(u,variant):
  seconds=g.get('SHOT_SECONDS',6)*u+g.get('SHOT_OFFSET',0);phase=start+seconds
  w1.rotation_euler.z=-seconds*.62/3;w2.rotation_euler.z=-seconds*.62/3
  for i,p in enumerate(cars):
   (x,y,a,z),s=at(phase+i*period/12,True);p.location=(x,y,z-4.08);p.rotation_euler.z=a
   op=smooth(7.2,7.9,abs(x));jaws[i].location.y=.40*op
   for sp in coils[i]:sp.scale.y=1-.22*op;sp.location.y=-.11*op
   for j,h in enumerate(running[i]):
    dx=[-.31,-.31,.31,.31][j];dy=[-.62,.62,-.62,.62][j]
    wx,wy,wa,wz=path(s+dx);wx-=math.sin(wa)*dy;wy+=math.cos(wa)*dy
    rx=wx-x;ry=wy-y;h.location=(rx*math.cos(a)+ry*math.sin(a),-rx*math.sin(a)+ry*math.cos(a),4.14)
    h.rotation_euler=(0,-s/.19,wa-a)
   if variant=='tension':
    for o in car_nodes[i]:
     if not o.hide_render:o.hide_render=True
  for o in forest:o.hide_render=variant not in ['landscape','ending']
  for h,v in conveyor_hubs:h.rotation_euler.y=-seconds*v/.258
  delta=.12*math.sin(u*math.tau) if variant=='tension' else 0
  w2.location.x=12+delta;g['scene'].objects[w2['axle_name']].location.x=12+delta
  for q,p0 in zip(cable.data.splines[0].points,cable_points):
   frac=max(0,min(1,(p0[0]+12)/24));sag=(.30+.13*math.sin(u*math.tau)) if variant=='tension' else 0
   q.co=(p0[0]+delta*frac,p0[1],p0[2]-sag*sag_shape(p0[0]),1)
  if variant=='drive':look((-11.7,0,3),(-10,15,9),19.7)
  elif variant=='loop':look((0,0,3),(0,4,27),39.5)
  elif variant=='tension':
   close=smooth(.35,.55,u)*(1-smooth(.89,1,u));look((13.3*close,0,2.8),(-18+25*close,22-12*close,12-7*close),40-28*close)
   delta=.12*math.sin(u*math.tau);tension.location.x=12+delta;ram.location.x=13.25+delta/2
  else:look((0,0,2.7),(-22,31,18),42)
  return None
 # Geometric / kinematic audit uses sample states rather than visual guesswork.
 tests={'cabin_count':12,'visibility_toggles_in_operating_views':0,'line_speed':.62,'station_speed':.14,'speed_ratio':.62/.14,'cycle_seconds':period,'same_asset_all_cabins':all(p.get('asset_id')=='explorer-cabin-v2' for p in cars)}
 tests['maximum_step_m']=max(math.dist(at(start+i/24)[:2],at(start+(i+1)/24)[:2]) for i in range(24*60))
 tests['closed_alignment_m']=max(abs(abs(at(t)[1])-3) for t in range(math.ceil(period)) if abs(at(t)[0])<7.2)
 assert tests['maximum_step_m']<.027 and tests['closed_alignment_m']<.001
 (Path(g['BASE'])/'overview-qa.json').write_text(json.dumps(tests,indent=2))
 return update
