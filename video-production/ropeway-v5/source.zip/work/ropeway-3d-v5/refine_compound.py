"""Context cue for an uninterrupted negative phrase; the cue is removed later."""
from pathlib import Path
import json, hashlib
B = Path(__file__).resolve().parent
W = B.parent
from tts_bootstrap import runtime, m
data = json.loads((B / 'speech-revisions.json').read_text(encoding='utf8'))
beat = next(b for b in data['beats'] if b['id'] == 's31b1')
provenance = json.loads((B / 'zh-reference-provenance.json').read_text(encoding='utf8'))
ref = runtime / 'CosyVoice/asset/zero_shot_prompt.wav'
assert hashlib.sha256(ref.read_bytes()).hexdigest() == provenance['reference_sha256']
model = m.AutoModel(model_dir=str(runtime / 'models/Fun-CosyVoice3-0.5B'), fp16=False)
m.torch.manual_seed(20261015)
spoken = '我们' + beat['text']
parts = [q['tts_speech'].cpu() for q in model.inference_zero_shot(spoken, 'You are a helpful assistant.<|endofprompt|>' + provenance['transcript'], str(ref), stream=False)]
a = m.torch.cat(parts, dim=1)
assert m.torch.isfinite(a).all()
p = B / 'audio-zh-raw/s31b1-context.wav'
m.torchaudio.save(str(p), a, model.sample_rate, format='wav')
(B / 'context-candidate.json').write_text(json.dumps({'synthesis_text': spoken, 'delivery_text': beat['text'], 'context_prefix': '我们', 'context_must_be_removed': True, 'audio_sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'mode': 'inference_zero_shot', 'reference': provenance, **m.validate_wav(p)}, ensure_ascii=False, indent=2), encoding='utf8')
