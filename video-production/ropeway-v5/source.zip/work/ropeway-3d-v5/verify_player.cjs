const {chromium}=require('C:/Users/Cesar/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('node:fs'),path=require('node:path');
const base=__dirname,final=true,pilot=process.argv.includes('--pilot');
const target=path.join(base,'../../outputs/ropeway-3d-v5-watch.html'); const duration=597.5;
const report={file:target,cases:[],errors:[],externalRequests:[],evidence:'Automated real-browser playback and UI checks. No physical-device or human-listening acceptance is implied.'};
const assert=(ok,why)=>{if(!ok)throw Error(why)};
(async()=>{
 const qaTemp=path.join(base,'qa-temp');fs.mkdirSync(qaTemp,{recursive:true});
 process.env.TEMP=qaTemp;process.env.TMP=qaTemp;
 const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--disable-gpu','--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:1380,height:1050}});
  page.on('pageerror',e=>report.errors.push(String(e)));
  page.on('request',r=>{if(/^https?:/i.test(r.url()))report.externalRequests.push(r.url().slice(0,180))});
  await page.goto('file:///'+target.replace(/\\/g,'/'),{waitUntil:'load',timeout:90000});
  await page.waitForFunction(()=>window.playerState?.().ready,{timeout:45000});
  if(final){report.selfContained=await page.evaluate(()=>document.getElementById('film').src.startsWith('data:video/mp4;')&&document.getElementById('mandarin').src.startsWith('data:audio/mp4;')&&document.getElementById('film').poster.startsWith('data:image/jpeg;'));assert(report.selfContained,'The final offline player must embed every media asset');}
  async function state(name){const s=await page.evaluate(()=>playerState());report.cases.push({name,...s});return s}
  async function pausedAt(t){await page.evaluate(t=>{document.getElementById('film').pause();jumpTo(t)},t);await page.waitForFunction(t=>!document.getElementById('film').seeking&&Math.abs(playerState().time-t)<.05,t);}
  let s=await state('default Mandarin, ready and paused');assert(s.language==='zh'&&s.videoMuted&&s.videoPaused&&s.audioPaused,'Default Mandarin state');
  await page.screenshot({path:path.join(base,pilot?'pilot-desktop.png':'full-desktop.png')});
  await page.click('#play');await page.waitForFunction(()=>!playerState().videoPaused&&!playerState().audioPaused&&playerState().time>.4);
  s=await state('Mandarin playing');assert(s.videoMuted&&Math.abs(s.time-s.audioTime)<.16,'Chinese stream must play alone and remain synchronized');
  let before=s.time;await page.click('[data-language=en]');s=await state('switch to English while playing');assert(!s.videoPaused&&s.audioPaused&&!s.videoMuted&&s.time>=before&&s.time-before<1,'English switch must retain playback and position');
  before=s.time;await page.click('[data-language=zh]');await page.waitForFunction(()=>!playerState().audioPaused);s=await state('switch back to Mandarin while playing');assert(s.videoMuted&&!s.videoPaused&&s.time>=before&&s.time-before<1&&Math.abs(s.time-s.audioTime)<.16,'Chinese switch must retain position');
  await page.click('#play');s=await state('pause stops both streams');assert(s.videoPaused&&s.audioPaused,'Pause synchronization');
  before=s.time;await page.click('[data-language=en]');await page.click('[data-language=zh]');s=await state('switch languages while paused');assert(s.videoPaused&&s.audioPaused&&Math.abs(s.time-before)<.03,'Paused switch must stay paused and retain position');
  await pausedAt(duration*.29);s=await state('seek forward while paused');assert(Math.abs(s.audioTime-s.time)<.05&&s.audioPaused,'Paused seek must align Mandarin');
  await page.click('#play');await page.waitForFunction(()=>!playerState().audioPaused);await page.evaluate(()=>jumpTo(211.5));await page.waitForFunction(()=>!document.getElementById('film').seeking&&!playerState().audioPaused);s=await state('seek while playing');assert(!s.videoPaused&&Math.abs(s.time-s.audioTime)<.16,'Playing seek synchronization');
  await page.evaluate(()=>{for(let i=0;i<12;i++)selectNarration(i%2?'zh':'en')});await page.waitForFunction(()=>playerState().language==='zh'&&!playerState().audioPaused);s=await state('twelve rapid language switches');assert(s.videoMuted&&!s.videoPaused&&Math.abs(s.time-s.audioTime)<.16&&!s.error,'Rapid switch must avoid competing streams');
  await page.selectOption('#speed','1.25');await page.waitForFunction(()=>playerState().audioRate===1.25);s=await state('1.25 playback speed');assert(s.rate===1.25&&s.audioRate===1.25,'Playback rates match');
  await page.click('#mute');s=await state('mute');assert(s.userMuted&&s.videoMuted&&await page.$eval('#mandarin',a=>a.muted),'Mute applies to both narrations');
  await page.click('[data-language=en]');s=await state('muted English switch');assert(s.userMuted&&s.videoMuted&&s.audioPaused,'Mute persists on language switch');
  await page.click('#mute');s=await state('unmute English');assert(!s.videoMuted&&!s.userMuted&&s.audioPaused,'English alone unmuted');
  await page.click('[data-language=zh]');await page.selectOption('#speed','1');
  await page.click('#fullscreen');assert(await page.evaluate(()=>!!document.fullscreenElement||document.getElementById('player').classList.contains('fallback-fullscreen')),'Full-screen entry');
  assert(await page.locator('[data-language=en]').isVisible(),'Language controls remain available in full screen');await state('fullscreen includes language controls');await page.click('#fullscreen');
  await page.click('#play');await page.setViewportSize({width:390,height:900});await page.screenshot({path:path.join(base,pilot?'pilot-mobile.png':'full-mobile.png')});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Mobile viewport horizontal overflow');
  for(const selector of ['#play','[data-language=zh]','[data-language=en]','#fullscreen']){const b=await page.locator(selector).boundingBox();assert(b.width>=44&&b.height>=40,'Touch target '+selector)}
  await state('390px viewport controls');await page.setViewportSize({width:1380,height:1050});
  await pausedAt(duration-.55);await page.click('#play');await page.waitForFunction(()=>document.getElementById('film').ended,{timeout:8000});s=await state('end stops both media');assert(s.audioPaused&&s.videoPaused,'End synchronization');
  await page.click('#play');await page.waitForFunction(()=>playerState().time<3&&!playerState().videoPaused&&!playerState().audioPaused);s=await state('replay after end');assert(Math.abs(s.time-s.audioTime)<.16,'Replay synchronized');
  await page.click('#play');assert(!report.errors.length,'Browser JavaScript errors: '+report.errors.join('; '));assert(!report.externalRequests.length,'Unexpected network dependency');
  report.ok=true;
 }catch(e){report.ok=false;report.failure=String(e);throw e}
 finally{await browser.close();fs.writeFileSync(path.join(base,pilot?'pilot-player-qa.json':'full-player-qa.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({ok:report.ok,cases:report.cases.length,failure:report.failure}));}
})().catch(e=>{console.error(e);process.exitCode=1});

