"""Original geometric models for the complete ropeway film.
All mechanisms are simplified teaching assemblies, not production CAD.
"""
import runpy,sys,json,math,time
from pathlib import Path
from mathutils import Vector
import bpy
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
D=runpy.run_path(str(BASE/'ropeway_scene.py'))
globals().update({k:D[k] for k in ['box','cylinder','tube','torus','empty','mat','M','scene','cam','carrier','moving','springs','rope','mapping','option','smooth','set_time','TOTAL']})
GROUPS={};UPDATES={}
initial=set(scene.objects)
keep={o for o in initial if o.type in ['CAMERA','LIGHT'] or o.name=='Ground'}
for o in initial-keep:o.hide_render=True
def capture(name,build):
 before=set(scene.objects);update=build();GROUPS[name]=set(scene.objects)-before;UPDATES[name]=update
 collection=bpy.data.collections.new(name.title()+' teaching model');scene.collection.children.link(collection)
 for o in GROUPS[name]:
  collection.objects.link(o)
  for old in list(o.users_collection):
   if old!=collection:old.objects.unlink(o)
_DESCEND_COUNT=-1
_DESCEND_MAP={}
_COPY_CHILDREN={}
def descend(o):
 global _DESCEND_COUNT,_DESCEND_MAP
 if _DESCEND_COUNT!=len(scene.objects):
  _DESCEND_MAP={}
  for q in scene.objects:
   if q.parent:_DESCEND_MAP.setdefault(q.parent,[]).append(q)
  _DESCEND_COUNT=len(scene.objects)
 result=[o]
 for c in _DESCEND_MAP.get(o,[]):result+=descend(c)
 return result
def copy_tree(src,par=None):
 o=src.copy();o.animation_data_clear();scene.collection.objects.link(o);o.parent=par;o.hide_render=False
 if src not in _COPY_CHILDREN:_COPY_CHILDREN[src]=tuple(src.children)
 for c in _COPY_CHILDREN[src]:copy_tree(c,o)
 return o
def sphere(name,loc,r,material,par=None,scale=(1,1,1)):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=r,location=loc)
 o=bpy.context.object;o.name=name;o.data.materials.append(material);o.parent=par;o.scale=scale
 for p in o.data.polygons:p.use_smooth=True
 return o
def link_cylinder(name,a,b,r,m,par=None):
 a=Vector(a);b=Vector(b);o=cylinder(name,(a+b)/2,r,(b-a).length,m,par)
 o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
SKIN=mat('Warm character skin',(.68,.38,.20),0,.65)
HAIR=mat('Brown hair',(.095,.046,.025),0,.8)
RED=mat('Safety attention orange',(.85,.12,.025),.1,.5)
BLUE=mat('Inspection blue',(.06,.22,.37),.05,.6)
def person(name,loc,child=False,role='adult',seated=False):
 p=empty(name,loc);sc=.73 if child else 1.0;p.scale=(sc,sc,sc);shirt=M['orange'] if child else (BLUE if role=='staff' else M['green'])
 hip=.67 if seated else .85;head=hip+.69
 box('Rounded coat',(0,0,hip+.28),(.40,.27,.48),shirt,p,.11)
 sphere('Friendly head',(0,0,head),.195,SKIN,p)
 sphere('Hair cap',(0,-.008,head+.08),.19,HAIR,p,(1,1,.65))
 for x in [-.067,.067]:sphere('Eyes',(x,.178,head+.022),.014,M['rubber'],p)
 tube('Smile',[(-.047,.184,head-.05),(0,.194,head-.066),(.047,.184,head-.05)],.007,HAIR,p)
 for x in [-.13,.13]:
  if seated:
   link_cylinder('Seated upper leg',(x,0,hip),(x,.32,hip-.06),.072,M['steel'],p)
   link_cylinder('Lower leg',(x,.32,hip-.06),(x,.32,.22),.063,M['steel'],p)
   box('Shoes',(x,.37,.16),(.16,.26,.10),M['rubber'],p,.045)
  else:
   link_cylinder('Leg',(x,0,hip),(x,0,.15),.071,M['steel'],p)
   box('Shoes',(x,.06,.10),(.16,.28,.12),M['rubber'],p,.045)
 for x in [-.25,.25]:
  link_cylinder('Sleeve',(x*.82,0,hip+.47),(x,.04,hip+.02),.065,shirt,p)
  sphere('Hands',(x,.04,hip+.02),.075,SKIN,p)
 if role=='staff':
  sphere('Safety helmet',(0,0,head+.12),.22,M['spring'],p,(1,1,.6))
  box('Reflective vest band',(0,.147,hip+.24),(.38,.017,.075),M['spring'],p,.005)
 return p
def look(target,offset,scale):
 target=Vector(target);cam.location=target+Vector(offset);cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale
def model_wheel(x,y,z,r=1.5):
 root=empty('Drive wheel assembly',(x,y,z));torus('Lined drive rim',(0,0,0),r-.085,.085,M['rubber'],root,axis='Z')
 cylinder('Drive hub',(0,0,0),.24,.17,M['steel'],root)
 for i in range(8):
  a=i*math.tau/8;link_cylinder('Drive wheel spoke',(.20*math.cos(a),.20*math.sin(a),0),((r-.12)*math.cos(a),(r-.12)*math.sin(a),0),.045,M['steel'],root)
 axle=cylinder('Axle',(x,y,z/2),.115,z,M['steel']);root['axle_name']=axle.name
 box('Wheel foundation',(x,y,.20),(2,1.8,.40),M['sage'],bevel=.14)
 from enhance import enhance_wheel
 enhance_wheel(globals(),root,r)
 return root
from overview import build_network
def network():return build_network(globals())
# Build the repeated circuit last, after the detailed small assemblies.

def wire_rope():
 parts=[]
 for strand in range(7):
  for wire in range(7):
   points=[]
   for i in range(121):
    x=-3+6*i/120;sa=x*1.7+(strand-1)*math.tau/6
    spread=.34 if x<.6 else .34+.48*smooth(.6,2.7,x)
    cy=0 if strand==0 else spread*math.cos(sa);cz=2.35+(0 if strand==0 else spread*math.sin(sa))
    wa=x*12+(wire-1)*math.tau/6;rr=0 if wire==0 else .095
    points.append((x,cy+rr*math.cos(wa),cz+rr*math.sin(wa)))
   parts.append(tube('Steel wire in a twisted strand',points,.046,M['spring'] if strand==0 else M['steel']))
 # Magnetizing detector surrounds a separate intact rope segment.
 head=empty('Magnetic rope inspection head')
 for z in [1.3,3.4]:box('Inspection housing',(0,0,z),(1.03,1.15,.40),M['green'],head,.09)
 for y in [-.63,.63]:box('Inspection housing side',(0,y,2.35),(1.03,.24,2.10),M['green'],head,.07)
 torus('Inspection sensor coil',(-.42,0,2.35),.70,.04,M['spring'],head,axis='X')
 computer=empty('Inspection computer assembly')
 box('Inspection computer',(2.2,1.3,1.5),(1.1,.18,.8),M['green'],computer);box('Inspection display',(2.2,1.405,1.5),(.92,.018,.62),M['glass'],computer)
 for i in range(10):box('Recorded magnetic signal',(1.81+i*.085,1.419,1.51),(.025,.016,.05+.16*abs(math.sin(i))),M['spring'],computer,bevel=.004)
 tube('Sensor data cable',[(.6,.6,1.3),(1.4,.7,.6),(2.2,1.3,1.1)],.022,M['rubber'],computer)
 inspection=set(descend(head)+descend(computer))
 # Hidden internal damage is represented only in the inspection cutaway.
 broken=box('Internal damaged wire example',(.4,0,2.35),(.16,.13,.13),RED,bevel=.025)
 def update(u,variant):
  for o in inspection:o.hide_render=variant!='inspection'
  broken.hide_render=variant!='inspection'
  look((0,0,2.4),(-2.6+1.1*math.sin(u*math.tau),8.5,3.7),8.7)
 return update
capture('wire',wire_rope)

def tower_model():
 box('Concrete tower foundation',(0,-1.35,.12),(2.1,2.4,.40),M['cream'],bevel=.08)
 box('Tower column',(0,-1.35,1.85),(.48,.53,3.3),M['sage'],bevel=.075)
 box('Sheave support beam',(0,-.38,3.46),(4.4,.30,.19),M['steel'])
 link_cylinder('Tower cantilever bracket',(0,-1.35,3.20),(0,-.38,3.46),.14,M['steel'])
 wheels=[]
 for i in range(6):
  x=-1.8+i*.72;p=empty('Sheave rotation',(x,0,3.808));wheels.append(p)
  torus('Grooved supporting sheave',(0,0,0),.195,.035,M['rubber'],p)
  cylinder('Sheave hub',(0,.075,0),.09,.13,M['steel'],p,axis='Y')
  box('Sheave rotation stripe',(0,.147,0),(.022,.015,.31),M['spring'],p,.005)
 for x in [-.36,.36]:link_cylinder('Tower stabilizing brace',(0,-1.35,2.8),(x,-.38,3.4),.055,M['steel'])
 cable=cylinder('Steel rope over tower',(0,0,4.08),.045,18,M['steel'],axis='X')
 c=copy_tree(carrier);c.scale=(1,1,1)
 swing=empty('Cabin swing pivot',(0,0,4.08),c)
 for o in list(c.children):
  if o==swing:continue
  if any(k in o.name for k in ['cabin','Cabin','Window','door','Door','Rigid','Hanger']):
   o.parent=swing;o.location.z-=4.08
 wind=empty('Wind instrument',(2.2,1.3,5.0))
 mast=cylinder('Wind instrument mast',(2.2,1.3,3),.042,4,M['steel'])
 for i in range(3):
  a=i*math.tau/3;link_cylinder('Anemometer arm',(0,0,0),(.3*math.cos(a),.3*math.sin(a),0),.02,M['steel'],wind)
  sphere('Anemometer cup',(.3*math.cos(a),.3*math.sin(a),0),.083,M['green'],wind)
 staff=person('Trained rescue team',(2.65,.9,.35),role='staff')
 person('Rescue team colleague',(3.4,.75,.35),role='staff')
 torus('Stored rescue rope',(2.9,1.8,.44),.23,.045,M['spring'],axis='Z')
 box('Rescue plan and equipment box',(2.9,1.8,.30),(1.4,.80,.40),M['green'])
 crew={o for o in scene.objects if o.name.startswith(('Trained rescue','Rescue team','Stored rescue','Rescue plan'))}
 for p in list(crew):crew.update(descend(p))
 def update(u,variant):
  if variant=='stop':travel=6*(1-(1-min(u/.48,1))**2);x=-3+travel;angle=.09*math.exp(-4*u)*math.sin(u*12)
  elif variant=='wind':travel=0;x=2.65;angle=.10*math.sin(u*math.tau*2)
  elif variant=='rescue':travel=0;x=1.25;angle=0
  else:travel=8*u;x=-4+travel;angle=0
  c.location=(x,0,0);swing.rotation_euler.x=angle
  for p in wheels:p.rotation_euler.y=-travel/.23
  wind.rotation_euler.z=u*math.tau*3
  wind.hide_render=variant!='wind'
  mast.hide_render=variant!='wind'
  for p in wind.children:p.hide_render=variant!='wind'
  for o in crew:o.hide_render=variant!='rescue'
  if variant=='tower':look((0,0,3.65),(-4,7,3.7),9.1)
  else:look((1,0,2.6),(-7,11,4.8),12.5)
 return update
from enhance import enhance_tower
_orig_tower=tower_model
def tower_model():
 update=_orig_tower();enhance_tower(globals());return update
capture('tower',tower_model)

def brake_model():
 wheel=model_wheel(0,0,3.6)
 cylinder('Service brake disc',(0,0,1.75),.68,.085,M['steel'])
 box('Drive gearbox',(-1.25,0,1.1),(1.15,.85,.68),M['sage'])
 cylinder('Station electric motor',(-2.1,0,1.1),.36,1.1,M['green'],axis='X')
 cylinder('Motor to gearbox shaft',(-1.4,0,1.1),.09,1.0,M['steel'],axis='X')
 for x in [-.34,.34]:box('Cutaway service brake caliper',(x,.80,1.75),(.10,.20,.54),M['orange'])
 box('Caliper lower bridge',(0,.80,1.51),(.78,.20,.08),M['orange'])
 upper=box('Spring-applied service pad',(0,.53,1.99),(.50,.28,.10),M['rubber'])
 lower=box('Lower service pad',(0,.53,1.6575),(.50,.28,.10),M['rubber'])
 box('Brake fixed spring support',(0,.53,2.81),(.67,.49,.10),M['green'])
 sp=[]
 for x in [-.15,.15]:
  points=[(x+.07*math.cos(i*math.tau/24),.53+.07*math.sin(i*math.tau/24),2.15+i/(8*24)*.61) for i in range(193)]
  sp.append(tube('Brake compression spring',points,.016,M['spring']))
  cylinder('Brake push rod',(x,0,.23),.038,.36,M['steel'],upper)
 box('Moving spring seat',(0,0,.135),(.62,.40,.05),M['steel'],upper)
 box('Emergency rim caliper',(1.71,0,3.6),(.24,.72,.66),M['orange'])
 box('Emergency pad above wheel',(1.44,0,3.747),(.23,.48,.12),M['rubber'])
 box('Emergency pad below wheel',(1.44,0,3.453),(.23,.48,.12),M['rubber'])
 backup=empty('Auxiliary drive assembly')
 cylinder('Auxiliary drive motor',(-2.1,-1.0,1.1),.29,1.0,BLUE,backup,axis='X')
 box('Auxiliary drive coupling',(-1.23,-.52,1.1),(.70,.55,.42),BLUE,backup)
 indicator=sphere('Permission indicator',(-1.3,-.70,1.57),.11,M['rail'])
 def update(u,variant):
  if variant=='spring-brake':
   contact=smooth(.63,.76,u);travel=min(u,.63)*4+(max(0,min(u-.63,.13))*.5)
   upper.location.z=1.99-.1475*contact
   for p in sp:p.scale.z=1+(.1475/.61)*contact;p.location.z=-2.76*(.1475/.61)*contact
   look((0,.38,2.06),(-3.5,6,2.4),4.9)
  else:
   upper.location.z=1.99
   for p in sp:p.scale.z=1;p.location.z=0
   travel=max(0,u-.43)*1.0 if variant=='backup' else u*math.tau*2
   look((-.40,0,2.25),(-6.5,8.5,5),9.4)
  wheel.rotation_euler.z=-travel
  scene.objects['Service brake disc'].rotation_euler.z=-travel
  for p in descend(backup):p.hide_render=variant!='backup'
  indicator.hide_render=variant!='backup' or u<.43
 return update
from enhance import enhance_drive
_orig_brake=brake_model
def brake_model():
 update=_orig_brake();enhance_drive(globals());return update
capture('brake',brake_model)

def boarding_model():
 c=copy_tree(carrier);c.location=(0,0,0)
 # One transparent teaching side reveals the seats and adult/child positions.
 for o in descend(c):
  if 'glass' in o.name and (o.location.y>0 or abs(o.location.x)>.8):o.hide_render=True;o['cutaway']=True
 box('Bench inside cabin',(0,-.28,1.49),(1.2,.40,.12),M['sage'])
 person('Adult passenger',(-.40,-.19,.88),seated=True)
 person('Child passenger',(.38,-.10,1.06),child=True,seated=True)
 person('Station attendant',(2.2,1.9,.62),role='staff')
 box('Passenger platform',(0,1.85,.46),(5.4,2.1,.31),M['sage'],bevel=.12)
 for x in [-1.5,-.6,.3,1.2]:box('Platform keep-clear line',(x,.92,.632),(.60,.08,.015),M['spring'],bevel=.005)
 for y in [-.62,.62]:tube('Station carrier rail',[(-3,y,3.903),(3,y,3.903)],.047,M['rail'])
 for x in [-2.5,2.5]:
  for y in [-.62,.62]:box('Rail support post',(x,y,1.93),(.12,.12,3.8),M['sage'])
 cylinder('Rope beyond station',(0,-2.0,4.08),.042,14,M['steel'],axis='X')
 moving_copy=next(o for o in descend(c) if o.name.startswith('Moving_grip_jaw'))
 moving_copy.location.y=.40
 box('Station handrail',(2.7,2.25,1.1),(.10,.10,1.2),M['white'])
 # Door frames remain visible; this side is a labelled explanatory cutaway.
 radio=box('Emergency communication panel',(.66,.64,1.8),(.24,.07,.26),M['cream'],c,.025)
 sphere('Communication button',(.66,.69,1.78),.035,M['orange'],c)
 def update(u,variant):
  for o in descend(c):
   if o.get('cutaway'):o.hide_render=True
  look((.5,.5,2.7),(-4.7,10,1.5),10.5 if variant=='boarding' else 9.6)
 return update
capture('boarding',boarding_model)

# Base grip and load path remain genuinely connected to the rope.
GROUPS['grip']=set(descend(carrier))|{rope}
def grip_update(u,variant):
 carrier.location=(0,0,0);carrier.rotation_euler=(0,0,0);moving.location.y=0
 for sp in springs:sp.scale=(1,1,1);sp.location=(0,0,0)
 mapping.inputs['Location'].default_value[2]=0
 if variant=='grip':
  for o in carrier.children:
   if (o.name.startswith('Carrier cross beam') and o.location.y>0) or (o.name.startswith('Running_wheel_pivot') and o.location.y>0):
    for child in descend(o):child.hide_render=True
  look((0,0,4.24),(-1.25,5.0,.85),3.30)
 else:look((0,0,2.75),(-5.4,8,3.3),10.5)
UPDATES['grip']=grip_update
GROUPS['station']=initial-keep
def station_update(u,variant):
 if variant=='circuit':
  set_time(39);carrier.location.x=4.6+.24*smooth(0,.33,u);moving.location.y=.23
  look((4.8,0,2.8),(4,8,3.6),10.4)
 else:set_time(22+u*3)
UPDATES['station']=station_update

def types_model():
 for i,(x,y) in enumerate([(-3.2,-.25),(3.2,.25)]):
  p=copy_tree(carrier);p.scale=(1,1,1);p.location=(x,y,0)
  cylinder('Hauling rope',(x,y,4.08),.042,5.3,M['steel'],axis='X')
  if i==1:
   for side in [-1,1]:cylinder('Separate carrying rope',(x,y+side*.62,3.95-.055),.055,5.3,M['green'],axis='X')
 def update(u,variant):look((0,0,2.7),(-1.8,12,3.2),15.8)
 return update
capture('types',types_model)

def control_model():
 for y in [-.83,.83]:box('Station check gate',(4.65,y,2.31),(.13,.13,4.50),M['sage'])
 box('Gate top',(4.65,0,4.58),(.13,1.79,.13),M['sage'])
 box('Grip-check unit',(4.67,.72,4.30),(.30,.27,.28),BLUE)
 light=sphere('Grip-check status',(4.67,.9,4.36),.078,M['rail'])
 box('Control desk',(3.3,1.83,.93),(1.2,.75,.25),M['green'])
 box('Safety controller screen',(3.3,2.09,1.5),(1.1,.16,.70),M['green'])
 screen=box('Controller status display',(3.3,2.19,1.5),(.95,.024,.55),M['glass'])
 for x in [2.99,3.22,3.45,3.68]:sphere('Control switch',(x,1.76,1.095),.035,M['spring'])
 tube('Safety-circuit wiring',[(4.67,.72,4.3),(4.8,1.0,3.0),(4.8,1.9,.60),(3.3,1.9,.90)],.015,BLUE)
 def update(u,variant):
  set_time(39);travel=.24*smooth(0,.33,u);carrier.location.x=4.6+travel
  moving.location.y=.23 if variant=='circuit' else 0
  for h in D['running']:h.rotation_euler.y=-travel/.19
  for h,v in D['tires']:h.rotation_euler.y=-travel/.258
  light.data.materials.clear();light.data.materials.append(RED if variant=='circuit' else M['rail'])
  look((4.0,.8,2.65),(5.5,9.0,3.1),11.4)
 return update
capture('control',control_model)
GROUPS['sensors']=GROUPS['station']|GROUPS['control'];UPDATES['sensors']=UPDATES['control']

def safety_layers():
 positions=[(-3,-.8),(0,-.8),(3,-.8),(-1.6,2.0),(1.6,2.0)]
 for i,(x,y) in enumerate(positions):
  box('Safety measure plinth',(x,y,.43),(2.2,1.7,.65),M['sage'],bevel=.13)
  if i==0:
   for off in [-.35,0,.35]:tube('Strong supporting wires',[(x-1,y+off,1.25),(x+1,y+off,1.25)],.056,M['steel'])
  elif i==1:
   torus('Magnetic inspection ring',(x,y,1.25),.39,.10,M['green'],axis='X')
   tube('Rope through inspection ring',[(x-1,y,1.25),(x+1,y,1.25)],.05,M['steel'])
  elif i==2:
   cylinder('Brake disc example',(x,y,1.25),.59,.12,M['steel'])
   box('Brake pad example',(x,y+.35,1.40),(.6,.35,.12),M['rubber'])
   for i2 in [-.18,.18]:tube('Brake spring example',[(x+i2+.07*math.cos(j*.45),y+.35+.07*math.sin(j*.45),1.48+j*.009) for j in range(70)],.018,M['spring'])
  elif i==3:
   box('Sensor housing',(x,y,1.2),(.80,.35,.65),BLUE)
   for z in [1.05,1.35]:sphere('Sensor lens',(x,y+.19,z),.095,M['spring'])
  else:person('Trained staff',(x,y,.76),role='staff')
 def update(u,variant):look((0,.5,1.5),(-6.0,10.0,5.6),13.6)
 return update
capture('layers',safety_layers)

def load_tower():
 box('Load-path tower foundation',(4.2,-1.35,.15),(1.8,2.1,.4),M['cream'])
 box('Load-path tower column',(4.2,-1.35,1.92),(.48,.53,3.3),M['sage'])
 box('Load-path sheave beam',(4.2,-.38,3.46),(4.4,.30,.19),M['steel'])
 link_cylinder('Load-path cantilever bracket',(4.2,-1.35,3.2),(4.2,-.38,3.46),.14,M['steel'])
 for off in [-1.8,-1.08,-.36,.36,1.08,1.8]:
  x=4.2+off
  torus('Load-path supporting sheave',(x,0,3.808),.195,.035,M['rubber'])
  cylinder('Load-path sheave hub',(x,.07,3.808),.08,.10,M['steel'],axis='Y')
  box('Load-path bearing mount',(x,-.38,3.704),(.21,.26,.30),M['green'])
  cylinder('Load-path supporting axle',(x,-.18,3.808),.045,.42,M['steel'],axis='Y')
 def update(u,variant):
  grip_update(u,'loadpath');look((1.7,0,2.6),(-7,12,3.4),14.3)
 return update
capture('loadtower',load_tower)
GROUPS['loadpath']=GROUPS['grip']|GROUPS['loadtower'];UPDATES['loadpath']=UPDATES['loadtower']

VARIANTS={
 'landscape':'network','loop':'network','drive':'network','tension':'network',
 'rope':'wire','inspection':'wire','tower':'tower','stop':'tower','wind':'tower','rescue':'tower',
 'grip':'grip','loadpath':'loadpath','roles':'grip','station-question':'station','circuit':'sensors','sensors':'sensors','types':'types','layers':'layers',
 'brakes':'brake','spring-brake':'brake','backup':'brake','boarding':'boarding','passengers':'boarding','wait':'boarding'}
def pose(variant,u):
 active=GROUPS[VARIANTS[variant]]
 # Visibility is constant within a shot. Avoid touching thousands of hidden
 # objects for every camera keyframe or projected callout anchor.
 if globals().get('_VISIBLE_VARIANT')!=variant:
  for objects in GROUPS.values():
   for o in objects:
    hidden=o not in active
    if o.hide_render!=hidden:o.hide_render=hidden
    if o.hide_viewport!=hidden:o.hide_viewport=hidden
  globals()['_VISIBLE_VARIANT']=variant
 UPDATES[VARIANTS[variant]](u,variant)
 if not globals().get('BAKING',False):bpy.context.view_layer.update()
def preview():
 dest=BASE/'family-previews';dest.mkdir(exist_ok=True)
 variants=option('--variants',','.join(VARIANTS)).split(',')
 for variant in variants:
  pose(variant,.70);scene.render.filepath=str(dest/f'{variant}.png');bpy.ops.render.render(write_still=True)
 (BASE/'model-inventory.json').write_text(json.dumps({'original_objects':len(scene.objects),'variants':VARIANTS,'model_groups':{k:len(v) for k,v in GROUPS.items()}},indent=2))
 bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'ropeway-model-library.blend'))
def render():
 dest=BASE/'family-frames';dest.mkdir(exist_ok=True);report=json.loads((BASE/'family-progress.json').read_text()) if (BASE/'family-progress.json').exists() else {};fps=24
 static={'grip','loadpath','roles','types','layers','rescue','boarding','passengers','wait'}
 variants=option('--variants',','.join(VARIANTS)).split(',')
 for variant in variants:
  folder=dest/variant;folder.mkdir(exist_ok=True);tic=time.time();count=1 if variant in static else 144
  for f in range(count):
   target=folder/f'{f:04d}.png'
   if option('--force','0')=='1' or not target.exists():
    pose(variant,f/count);scene.render.filepath=str(target);bpy.ops.render.render(write_still=True)
   if f%24==0:
    report[variant]={'rendered':f+1,'total':count,'seconds':time.time()-tic}
    (BASE/'family-progress.json').write_text(json.dumps(report))
  report[variant]={'rendered':count,'total':count,'seconds':time.time()-tic}
  (BASE/'family-progress.json').write_text(json.dumps(report))
 (BASE/'family-done.json').write_text(json.dumps(report))
 pose('landscape',.25)
 bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'ropeway-model-library.blend'))
from intermediate import build_intermediate
capture('intermediate',lambda:build_intermediate(globals()))
VARIANTS['intermediate']='intermediate'
if option('--skip-network','0')!='1':capture('network',network)
_DESCEND_COUNT=-1

mode=option('--mode','family-preview')
if mode=='family-preview':preview()
elif mode=='family-render':render()
