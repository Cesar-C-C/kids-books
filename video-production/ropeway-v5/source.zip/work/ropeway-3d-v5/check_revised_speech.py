from pathlib import Path
import json, sys, os, site, hashlib, re
from difflib import SequenceMatcher
B = Path(__file__).resolve().parent
W = B.parent
RT = Path('C:/ProgramData/FunCosyVoice3')
os.environ['NUMBA_CACHE_DIR'] = str(B / 'tts-cache/numba')
os.environ['TEMP'] = str(B / 'tts-cache')
site.addsitedir(str(RT / '.venv/Lib/site-packages'))
dlls = [os.add_dll_directory(str(RT / '.venv/Lib/site-packages/torch/lib')), os.add_dll_directory(str(RT / '.venv/Library/bin'))]
import whisper, torch, numpy as np, soundfile as sf
from scipy.signal import resample_poly
torch.set_num_threads(3)
model = whisper.load_model(str(W / 'asr-models/small.pt'), device='cpu')
data = json.loads((B / 'speech-revisions.json').read_text(encoding='utf8'))
report = []
context = '--context' in sys.argv
final = '--final' in sys.argv
beats = [b.copy() for b in data['beats'] if not context or b['id'] == 's31b1']
for beat in beats:
    if context:
        beat['text'] = '我们' + beat['text']
    path = B / ('audio-zh-prepared' if final else 'audio-zh-raw') / (beat['id'] + ('-context' if context else '') + '.wav')
    a, sr = sf.read(path)
    audio = resample_poly(a, 16000, sr).astype('float32')
    q = model.transcribe(audio, language='zh', fp16=False, temperature=0, condition_on_previous_text=False,
                         word_timestamps=True, initial_prompt='简体中文。索道、吊厢、行走轮、轨道。')
    norm = lambda s: re.sub(r'[^\u4e00-\u9fff]', '', s)
    words = [w for seg in q['segments'] for w in seg.get('words', [])]
    row = {'id': beat['id'], 'text': beat['text'], 'recognized': q['text'],
           'similarity': SequenceMatcher(None, norm(beat['text']), norm(q['text'])).ratio(),
           'audio_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'words': words}
    report.append(row)
    name = 'speech-asr-context.json' if context else 'speech-asr-final.json' if final else 'speech-asr-review.json'
    (B / name).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps(row, ensure_ascii=False), flush=True)
