"""Replace three Mandarin slots without shifting the film's narration timeline."""
from pathlib import Path
import subprocess, json, hashlib, wave
import numpy as np

B = Path(__file__).resolve().parent
R = B.parents[1]
FF = R / 'work/video-tools/node_modules/@ffmpeg-installer/win32-x64/ffmpeg.exe'
SR = 24000

def read(path):
    return np.frombuffer(subprocess.check_output([str(FF), '-v', 'error', '-i', str(path),
        '-f', 'f32le', '-ac', '1', '-ar', str(SR), '-']), dtype='<f4').copy()

def wav(path, audio):
    with wave.open(str(path), 'wb') as f:
        f.setparams((1, 2, SR, 0, 'NONE', ''))
        f.writeframes((np.clip(audio, -.999, .999) * 32767).astype('<i2').tobytes())

def voice_rms(a):
    chunks = a[:len(a) // 240 * 240].reshape(-1, 240)
    energy = np.mean(chunks ** 2, axis=1)
    active = energy > .006 ** 2
    assert active.any()
    return float(np.sqrt(np.mean(energy[active])))

data = json.loads((B / 'speech-revisions.json').read_text(encoding='utf8'))
baseline = read(R / 'work/ropeway-3d-v4/narration-zh.m4a')[:round(597.5 * SR)]
assert len(baseline) == round(597.5 * SR)
full = baseline.copy()
changed = np.zeros(len(full), dtype=bool)
out = B / 'audio-zh-prepared'
out.mkdir(exist_ok=True)
report = []
for b in data['beats']:
    source = B / 'audio-zh-raw' / (b['id'] + ('-context' if b['id'] == 's31b1' else '') + '.wav')
    a = read(source)
    prefix_crop = .51 if b['id'] == 's31b1' else 0
    if prefix_crop:
        # DTW put the boundary at .48; waveform inspection found the old nasal tail
        # through .50 and the target consonant closure/burst starting around .51.
        a = a[round(prefix_crop * SR):]
    active = np.flatnonzero(np.abs(a) > .006)
    assert len(active)
    trim0 = max(0, active[0] - round(.05 * SR))
    trim1 = min(len(a), active[-1] + round(.07 * SR))
    a = a[trim0:trim1]
    start = round(b['start'] * SR)
    end = round((b['next_start'] - .04) * SR)
    available = (end - start) / SR
    tempo = max(1.0, len(a) / SR / (available - .025))
    assert tempo <= 1.35
    trim_path = out / (b['id'] + '-trim.wav')
    wav(trim_path, a)
    if tempo > 1.0001:
        adjusted = out / (b['id'] + '-tempo.wav')
        subprocess.run([str(FF), '-v', 'error', '-y', '-i', str(trim_path), '-af',
            f'atempo={tempo:.9f}', '-c:a', 'pcm_s16le', str(adjusted)], check=True)
        a = read(adjusted)
    target_rms = voice_rms(baseline[start:end])
    gain = target_rms / voice_rms(a)
    # Match the surrounding voice's energy; limit short peaks instead of reducing
    # the entire new sentence to accommodate a single synthesis transient.
    limiter_input = out / (b['id'] + '-limiter-input.f32')
    limiter_input.write_bytes(a.astype('<f4').tobytes())
    limited = out / (b['id'] + '-limited.wav')
    subprocess.run([str(FF), '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '1',
        '-i', str(limiter_input), '-af',
        f'volume={gain:.9f},apad=pad_len=120,alimiter=limit=0.84:level=false:attack=5:release=50,atrim=start_sample=120:end_sample={len(a)+120}',
        '-c:a', 'pcm_s16le', str(limited)], check=True)
    a = read(limited)
    fade = min(120, len(a) // 3)
    a[:fade] *= np.linspace(0, 1, fade)
    a[-fade:] *= np.linspace(1, 0, fade)
    assert len(a) <= end - start and np.isfinite(a).all()
    full[start:end] = 0
    full[start:start + len(a)] = a
    changed[start:end] = True
    path = out / (b['id'] + '.wav')
    wav(path, a)
    row = {'id': b['id'], 'delivery_text': b['text'], 'subtitle': b['subtitle'],
           'synthesis_text': ('我们' if prefix_crop else '') + b['text'],
           'synthesis_audio_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
           'removed_context_prefix': '我们' if prefix_crop else None,
           'context_crop_seconds': prefix_crop, 'outer_trim_seconds': [trim0 / SR, (trim1 - trim0) / SR],
           'slot': [start / SR, end / SR], 'fitted_duration': len(a) / SR, 'tempo': tempo,
           'rms_gain': gain, 'target_rms': target_rms, 'prepared_voice_rms': voice_rms(a),
           'loudness_delta_db': float(20 * np.log10(voice_rms(a) / target_rms)),
           'peak': float(np.max(np.abs(a))),
           'prepared_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    report.append(row)
assert np.array_equal(full[~changed], baseline[~changed])
(B / 'narration-zh.f32').write_bytes(full.astype('<f4').tobytes())
subprocess.run([str(FF), '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '1',
    '-i', str(B / 'narration-zh.f32'), '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart',
    str(B / 'narration-zh.m4a')], check=True)
qa = {'duration': 597.5, 'sample_rate': SR, 'replacement_count': len(report), 'replacements': report,
      'pcm_outside_three_slots_bit_identical_before_aac_encoding': True,
      'encoding_note': 'The complete Mandarin AAC is re-encoded once after slot replacement; its decoded samples are not claimed bit-identical outside those slots.',
      'narration_timeline_unchanged': True, 'new_speech_fits_existing_slots': True}
(B / 'audio-patch-qa.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(qa, ensure_ascii=False))
